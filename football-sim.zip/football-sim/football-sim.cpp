/*
****************************************************************************************************
* Justin Piper
* Capstone Project
* w/ Professor Spetka
* Fall 2023
****************************************************************************************************
*/

#include <iostream>
#include <fstream>
#include <sstream>
#include <random>
#include <string>
#include <string.h>
#include <HTTPRequest.hpp>
#include <PlayerObjects.h>
#include <TeamObjects.h>
#include <GameObjects.h>
#include <LeagueObjects.h>

using namespace std;
using namespace http;

vector<vector<string>> CSVParse(string f);

void print2DArray(vector<vector<string>> array);

void printPlayerData(array<Team, 32> teams);

void playWeek16Games(Team& t1, Team& t2, Team& t3, Team& t4, Team& t5, Team& t6, Team& t7, Team& t8,
    Team& t9, Team& t10, Team& t11, Team& t12, Team& t13, Team& t14, Team& t15, Team& t16,
    Team& t17, Team& t18, Team& t19, Team& t20, Team& t21, Team& t22, Team& t23, Team& t24,
    Team& t25, Team& t26, Team& t27, Team& t28, Team& t29, Team& t30, Team& t31, Team& t32);

void playWeek15Games(Team& t1, Team& t2, Team& t3, Team& t4, Team& t5, Team& t6, Team& t7, Team& t8,
    Team& t9, Team& t10, Team& t11, Team& t12, Team& t13, Team& t14, Team& t15, Team& t16,
    Team& t17, Team& t18, Team& t19, Team& t20, Team& t21, Team& t22, Team& t23, Team& t24,
    Team& t25, Team& t26, Team& t27, Team& t28, Team& t29, Team& t30);

void playWeek14Games(Team& t1, Team& t2, Team& t3, Team& t4, Team& t5, Team& t6, Team& t7, Team& t8,
    Team& t9, Team& t10, Team& t11, Team& t12, Team& t13, Team& t14, Team& t15, Team& t16,
    Team& t17, Team& t18, Team& t19, Team& t20, Team& t21, Team& t22, Team& t23, Team& t24,
    Team& t25, Team& t26, Team& t27, Team& t28);

void playWeek13Games(Team& t1, Team& t2, Team& t3, Team& t4, Team& t5, Team& t6, Team& t7, Team& t8,
    Team& t9, Team& t10, Team& t11, Team& t12, Team& t13, Team& t14, Team& t15, Team& t16,
    Team& t17, Team& t18, Team& t19, Team& t20, Team& t21, Team& t22, Team& t23, Team& t24,
    Team& t25, Team& t26);

int main()
{
    srand(time(0));

    string responseCSV;

    cout << " /$$   /$$ /$$$$$$$$ /$$           /$$$$$$  /$$$$$$ /$$       /$$\n"
         << "| $$$ | $$| $$_____/| $$          /$$__  $$|_  $$_/| $$$     /$$$\n"
         << "| $$$$| $$| $$      | $$         | $$  \\__/  | $$  | $$$$   /$$$$\n" 
         << "| $$ $$ $$| $$$$$   | $$         |  $$$$$$   | $$  | $$ $$ /$$ $$\n" 
         << "| $$  $$$$| $$__/   | $$          \\____  $$  | $$  | $$   $$$| $$\n"
         << "| $$\\  $$$| $$      | $$          /$$  \\ $$  | $$  | $$ \\  $ | $$\n"
         << "| $$ \\  $$| $$      | $$$$$$$$   |  $$$$$$/ /$$$$$$| $$  \\/  | $$\n"
         << "|__/  \\__/|__/      |________/    \\______/ |______/|__/      |__/ v1.0.0\n" << endl;
    cout << "by Justin Piper\n" << endl;

    try
    {
        string method = "GET";
        string body = "";
        string authHeader = "ed97f209-b805-4877-be6e-efe425:MYSPORTSFEEDS";
        HeaderFields headers;
        headers.push_back({ "Authorization", "Basic " + encodeBase64(authHeader.begin(), authHeader.end()) });
        chrono::milliseconds timeout = 20000ms;

        cout << "[Getting player data . . .]" << endl;

        Request request{ "http://api.mysportsfeeds.com/v2.1/pull/nfl/2023-2024-regular/player_stats_totals_projections.csv" };

        // send a get request
        const auto response = request.send(method, body, headers, timeout);
        responseCSV = string{ response.body.begin() + 1720, response.body.end() };

        cout << "[Complete!]" << endl;
    }
    catch (const exception& e)
    {
        cerr << "Request failed, error: " << e.what() << '\n';
    }

    vector<vector<string>> playerData = CSVParse(responseCSV);

    cout << "[Creating rosters . . .]" << endl;

    //BILLS TEAM CREATION****************************************************************************************************

    QB bufQB("Josh Allen", playerData);
    WR bufWR1("Stefon Diggs", playerData);
    WR bufWR2("Gabe Davis", playerData);
    WR bufWR3("Khalil Shakir", playerData);
    RB bufRB("James Cook", playerData);
    TE bufTE("Dalton Kincaid", playerData);
    DE bufDE1("Greg Rousseau", playerData);
    DE bufDE2("Ed Oliver", playerData);
    DE bufDE3("Tim Settle", playerData);
    DE bufDE4("Von Miller", playerData);
    DE bufDE5("Tyrel Dodson", playerData);
    DE bufDE6("Terrel Bernard", playerData);
    K bufK("Tyler Bass", playerData);
    P bufP("Sam Martin", playerData);
    R bufR("Deonte Harty", playerData);

    //make offense structure (takes QB, WR vector size = 3, TE, RB)
    array<WR, 3> bufWR{ bufWR1, bufWR2, bufWR3 };
    Offense bufOff(bufQB, bufWR, bufTE, bufRB);

    //make defense structure (takes DE vector size = 6)
    array<DE, 6> bufDE{ bufDE1, bufDE2, bufDE3, bufDE4, bufDE5, bufDE6 };
    Defense bufDef(bufDE);

    //make special teams structure
    STeams bufST(bufK, bufP, bufR);

    //DOLPHINS TEAM CREATION****************************************************************************************************

    QB miaQB("Tua Tagovailoa", playerData);
    WR miaWR1("Tyreek Hill", playerData);
    WR miaWR2("Jaylen Waddle", playerData);
    WR miaWR3("Braxton Berrios", playerData);
    RB miaRB("Raheem Mostert", playerData);
    TE miaTE("Durham Smythe", playerData);
    DE miaDE1("Christian Wilkins", playerData);
    DE miaDE2("Raekwon Davis", playerData);
    DE miaDE3("Zach Sieler", playerData);
    DE miaDE4("Andrew Van Ginkel", playerData);
    DE miaDE5("David Long Jr.", playerData);
    DE miaDE6("Jerome Baker", playerData);
    K miaK("Jason Sanders", playerData);
    P miaP("Jake Bailey", playerData);
    R miaR("Cedrick Wilson Jr.", playerData);

    //make offense structure (takes QB, WR vector size = 3, TE, RB)
    array<WR, 3> miaWR{ miaWR1, miaWR2, miaWR3 };
    Offense miaOff(miaQB, miaWR, miaTE, miaRB);

    //make defense structure (takes DE vector size = 6)
    array<DE, 6> miaDE{ miaDE1, miaDE2, miaDE3, miaDE4, miaDE5, miaDE6 };
    Defense miaDef(miaDE);

    //make special teams structure
    STeams miaST(miaK, miaP, miaR);

    //PATRIOTS TEAM CREATION****************************************************************************************************

    QB neQB("Mac Jones", playerData);
    WR neWR1("DeVante Parker", playerData);
    WR neWR2("Demario Douglas", playerData);
    WR neWR3("JuJu Smith-Schuster", playerData);
    RB neRB("Rhamondre Stevenson", playerData);
    TE neTE("Hunter Henry", playerData);
    DE neDE1("Deatrich Wise Jr.", playerData);
    DE neDE2("Davon Godchaux", playerData);
    DE neDE3("Lawrence Guy Sr.", playerData);
    DE neDE4("Anfernee Jennings", playerData);
    DE neDE5("Ja'Whaun Bentley", playerData);
    DE neDE6("Jahlani Tavai", playerData);
    K neK("Nick Folk", playerData);
    P neP("Bryce Baringer", playerData);
    R neR("Myles Bryant", playerData);

    //make offense structure (takes QB, WR vector size = 3, TE, RB)
    array<WR, 3> neWR{ neWR1, neWR2, neWR3 };
    Offense neOff(neQB, neWR, neTE, neRB);

    //make defense structure (takes DE vector size = 6)
    array<DE, 6> neDE{ neDE1, neDE2, neDE3, neDE4, neDE5, neDE6 };
    Defense neDef(neDE);

    //make special teams structure
    STeams neST(neK, neP, neR);

    //JETS TEAM CREATION****************************************************************************************************

    QB nyjQB("Aaron Rodgers", playerData);
    WR nyjWR1("Garrett Wilson", playerData);
    WR nyjWR2("Allen Lazard", playerData);
    WR nyjWR3("Xavier Gipson", playerData);
    RB nyjRB("Breece Hall", playerData);
    TE nyjTE("Tyler Conklin", playerData);
    DE nyjDE1("John Franklin-Myers", playerData);
    DE nyjDE2("Quinton Jefferson", playerData);
    DE nyjDE3("Quinnen Williams", playerData);
    DE nyjDE4("Jermaine Johnson", playerData);
    DE nyjDE5("Jamien Sherwood", playerData);
    DE nyjDE6("C.J. Mosley", playerData);
    K nyjK("Greg Zuerlein", playerData);
    P nyjP("Thomas Morstead", playerData);
    R nyjR("D.J. Reed", playerData);

    //make offense structure (takes QB, WR vector size = 3, TE, RB)
    array<WR, 3> nyjWR{ nyjWR1, nyjWR2, nyjWR3 };
    Offense nyjOff(nyjQB, nyjWR, nyjTE, nyjRB);

    //make defense structure (takes DE vector size = 6)
    array<DE, 6> nyjDE{ nyjDE1, nyjDE2, nyjDE3, nyjDE4, nyjDE5, nyjDE6 };
    Defense nyjDef(nyjDE);

    //make special teams structure
    STeams nyjST(nyjK, nyjP, nyjR);

    //RAVENS TEAM CREATION****************************************************************************************************

    QB lamar("Lamar Jackson", playerData);
    WR zay("Zay Flowers", playerData);
    WR rashod("Rashod Bateman", playerData);
    WR odell("Odell Beckham Jr.", playerData);
    RB jk("J.K. Dobbins", playerData);
    TE mark("Mark Andrews", playerData);
    DE odafe("Odafe Oweh", playerData);
    DE roquan("Roquan Smith", playerData);
    DE queen("Patrick Queen", playerData);
    DE clowney("Jadeveon Clowney", playerData);
    DE madubuike("Justin Madubuike", playerData);
    DE pierce("Michael Pierce", playerData);
    K justin("Justin Tucker", playerData);
    P jordan("Jordan Stout", playerData);
    R devin("Devin Duvernay", playerData);

    //make offense structure (takes QB, WR vector size = 3, TE, RB)
    array<WR, 3> balWR{ zay, rashod, odell };
    Offense balOff(lamar, balWR, mark, jk);

    //make defense structure (takes DE vector size = 6)
    array<DE, 6> balDE{ odafe, roquan, queen, clowney, madubuike, pierce };
    Defense balDef(balDE);

    //make special teams structure
    STeams balST(justin, jordan, devin);

    //BENGALS TEAM CREATION****************************************************************************************************

    QB cinQB("Joe Burrow", playerData);
    WR cinWR1("Ja'Marr Chase", playerData);
    WR cinWR2("Tee Higgins", playerData);
    WR cinWR3("Tyler Boyd", playerData);
    RB cinRB("Joe Mixon", playerData);
    TE cinTE("Tanner Hudson", playerData);
    DE cinDE1("Sam Hubbard", playerData);
    DE cinDE2("DJ Reader", playerData);
    DE cinDE3("BJ Hill", playerData);
    DE cinDE4("Trey Hendrickson", playerData);
    DE cinDE5("Logan Wilson", playerData);
    DE cinDE6("Germaine Pratt", playerData);
    K cinK("Evan McPherson", playerData);
    P cinP("Brad Robbins", playerData);
    R cinR("Trenton Irwin", playerData);

    //make offense structure (takes QB, WR vector size = 3, TE, RB)
    array<WR, 3> cinWR{ cinWR1, cinWR2, cinWR3 };
    Offense cinOff(cinQB, cinWR, cinTE, cinRB);

    //make defense structure (takes DE vector size = 6)
    array<DE, 6> cinDE{ cinDE1, cinDE2, cinDE3, cinDE4, cinDE5, cinDE6 };
    Defense cinDef(cinDE);

    //make special teams structure
    STeams cinST(cinK, cinP, cinR);

    //BROWNS TEAM CREATION****************************************************************************************************

    QB cleQB("Deshaun Watson", playerData);
    WR cleWR1("Amari Cooper", playerData);
    WR cleWR2("Elijah Moore", playerData);
    WR cleWR3("Cedric Tillman", playerData);
    RB cleRB("Nick Chubb", playerData);
    TE cleTE("David Njoku", playerData);
    DE cleDE1("Myles Garrett", playerData);
    DE cleDE2("Dalvin Tomlinson", playerData);
    DE cleDE3("Jordan Elliott", playerData);
    DE cleDE4("Za'Darius Smith", playerData);
    DE cleDE5("Jeremiah Owusu-Koramoah", playerData);
    DE cleDE6("Anthony Walker Jr.", playerData);
    K cleK("Dustin Hopkins", playerData);
    P cleP("Corey Bojorquez", playerData);
    R cleR("James Proche II", playerData);

    //make offense structure (takes QB, WR vector size = 3, TE, RB)
    array<WR, 3> cleWR{ cleWR1, cleWR2, cleWR3 };
    Offense cleOff(cleQB, cleWR, cleTE, cleRB);

    //make defense structure (takes DE vector size = 6)
    array<DE, 6> cleDE{ cleDE1, cleDE2, cleDE3, cleDE4, cleDE5, cleDE6 };
    Defense cleDef(cleDE);

    //make special teams structure
    STeams cleST(cleK, cleP, cleR);

    //STEELERS TEAM CREATION****************************************************************************************************

    QB pitQB("Kenny Pickett", playerData);
    WR pitWR1("Diontae Johnson", playerData);
    WR pitWR2("George Pickens", playerData);
    WR pitWR3("Allen Robinson II", playerData);
    RB pitRB("Najee Harris", playerData);
    TE pitTE("Pat Freiermuth", playerData);
    DE pitDE1("Larry Ogunjobi", playerData);
    DE pitDE2("Montravius Adams", playerData);
    DE pitDE3("Cameron Heyward", playerData);
    DE pitDE4("T.J. Watt", playerData);
    DE pitDE5("Mykal Walker", playerData);
    DE pitDE6("Elandon Roberts", playerData);
    K pitK("Chris Boswell", playerData);
    P pitP("Pressley Harvin III", playerData);
    R pitR("Calvin Austin III", playerData);

    //make offense structure (takes QB, WR vector size = 3, TE, RB)
    array<WR, 3> pitWR{ pitWR1, pitWR2, pitWR3 };
    Offense pitOff(pitQB, pitWR, pitTE, pitRB);

    //make defense structure (takes DE vector size = 6)
    array<DE, 6> pitDE{ pitDE1, pitDE2, pitDE3, pitDE4, pitDE5, pitDE6 };
    Defense pitDef(pitDE);

    //make special teams structure
    STeams pitST(pitK, pitP, pitR);

    //TEXANS TEAM CREATION****************************************************************************************************

    QB houQB("C.J. Stroud", playerData);
    WR houWR1("Nico Collins", playerData);
    WR houWR2("Tank Dell", playerData);
    WR houWR3("Noah Brown", playerData);
    RB houRB("Devin Singletary", playerData);
    TE houTE("Dalton Schultz", playerData);
    DE houDE1("Will Anderson Jr.", playerData);
    DE houDE2("Maliek Collins", playerData);
    DE houDE3("Sheldon Rankins", playerData);
    DE houDE4("Jonathan Greenard", playerData);
    DE houDE5("Henry To'oTo'o", playerData);
    DE houDE6("Denzel Perryman", playerData);
    K houK("Ka'imi Fairbairn", playerData);
    P houP("Cameron Johnston", playerData);
    R houR("Robert Woods", playerData);

    //make offense structure (takes QB, WR vector size = 3, TE, RB)
    array<WR, 3> houWR{ houWR1, houWR2, houWR3 };
    Offense houOff(houQB, houWR, houTE, houRB);

    //make defense structure (takes DE vector size = 6)
    array<DE, 6> houDE{ houDE1, houDE2, houDE3, houDE4, houDE5, houDE6 };
    Defense houDef(houDE);

    //make special teams structure
    STeams houST(houK, houP, houR);

    //COLTS TEAM CREATION****************************************************************************************************

    QB indQB("Anthony Richardson", playerData);
    WR indWR1("Michael Pittman Jr.", playerData);
    WR indWR2("Josh Downs", playerData);
    WR indWR3("Alec Pierce", playerData);
    RB indRB("Jonathan Taylor", playerData);
    TE indTE("Drew Ogletree", playerData);
    DE indDE1("Kwity Paye", playerData);
    DE indDE2("DeForest Buckner", playerData);
    DE indDE3("Taven Bryan", playerData);
    DE indDE4("Samson Ebukam", playerData);
    DE indDE5("E.J. Speed", playerData);
    DE indDE6("Zaire Franklin", playerData);
    K indK("Matt Gay", playerData);
    P indP("Rigoberto Sanchez", playerData);
    R indR("Isaiah McKenzie", playerData);

    //make offense structure (takes QB, WR vector size = 3, TE, RB)
    array<WR, 3> indWR{ indWR1, indWR2, indWR3 };
    Offense indOff(indQB, indWR, indTE, indRB);

    //make defense structure (takes DE vector size = 6)
    array<DE, 6> indDE{ indDE1, indDE2, indDE3, indDE4, indDE5, indDE6 };
    Defense indDef(indDE);

    //make special teams structure
    STeams indST(indK, indP, indR);

    //JAGUARS TEAM CREATION****************************************************************************************************

    QB jaxQB("Trevor Lawrence", playerData);
    WR jaxWR1("Calvin Ridley", playerData);
    WR jaxWR2("Christian Kirk", playerData);
    WR jaxWR3("Zay Jones", playerData);
    RB jaxRB("Travis Etienne Jr.", playerData);
    TE jaxTE("Evan Engram", playerData);
    DE jaxDE1("Adam Gotsis", playerData);
    DE jaxDE2("Folorunso Fatukasi", playerData);
    DE jaxDE3("Roy Robertson-Harris", playerData);
    DE jaxDE4("Josh Allen", playerData);
    DE jaxDE5("Devin Lloyd", playerData);
    DE jaxDE6("Foyesade Oluokun", playerData);
    K jaxK("Brandon McManus", playerData);
    P jaxP("Logan Cooke", playerData);
    R jaxR("Parker Washington", playerData);

    //make offense structure (takes QB, WR vector size = 3, TE, RB)
    array<WR, 3> jaxWR{ jaxWR1, jaxWR2, jaxWR3 };
    Offense jaxOff(jaxQB, jaxWR, jaxTE, jaxRB);

    //make defense structure (takes DE vector size = 6)
    array<DE, 6> jaxDE{ jaxDE1, jaxDE2, jaxDE3, jaxDE4, jaxDE5, jaxDE6 };
    Defense jaxDef(jaxDE);

    //make special teams structure
    STeams jaxST(jaxK, jaxP, jaxR);

    //TITANS TEAM CREATION****************************************************************************************************

    QB tenQB("Ryan Tannehill", playerData);
    WR tenWR1("DeAndre Hopkins", playerData);
    WR tenWR2("Treylon Burks", playerData);
    WR tenWR3("Nick Westbrook-Ikhine", playerData);
    RB tenRB("Derrick Henry", playerData);
    TE tenTE("Chigoziem Okonkwo", playerData);
    DE tenDE1("Jeffery Simmons", playerData);
    DE tenDE2("Teair Tart", playerData);
    DE tenDE3("Denico Autry", playerData);
    DE tenDE4("Harold Landry III", playerData);
    DE tenDE5("Jack Gibbens", playerData);
    DE tenDE6("Azeez Al-Shaair", playerData);
    K tenK("Nick Folk", playerData);
    P tenP("Ryan Stonehouse", playerData);
    R tenR("Eric Garror", playerData);

    //make offense structure (takes QB, WR vector size = 3, TE, RB)
    array<WR, 3> tenWR{ tenWR1, tenWR2, tenWR3 };
    Offense tenOff(tenQB, tenWR, tenTE, tenRB);

    //make defense structure (takes DE vector size = 6)
    array<DE, 6> tenDE{ tenDE1, tenDE2, tenDE3, tenDE4, tenDE5, tenDE6 };
    Defense tenDef(tenDE);

    //make special teams structure
    STeams tenST(tenK, tenP, tenR);

    //BRONCOS TEAM CREATION****************************************************************************************************

    QB denQB("Russell Wilson", playerData);
    WR denWR1("Courtland Sutton", playerData);
    WR denWR2("Jerry Jeudy", playerData);
    WR denWR3("Tim Patrick", playerData);
    RB denRB("Javonte Williams", playerData);
    TE denTE("Adam Trautman", playerData);
    DE denDE1("Jonathan Harris", playerData);
    DE denDE2("D.J. Jones", playerData);
    DE denDE3("Zach Allen", playerData);
    DE denDE4("Nik Bonitto", playerData);
    DE denDE5("Alex Singleton", playerData);
    DE denDE6("Josey Jewell", playerData);
    K denK("Wil Lutz", playerData);
    P denP("Riley Dixon", playerData);
    R denR("Marvin Mims Jr.", playerData);

    //make offense structure (takes QB, WR vector size = 3, TE, RB)
    array<WR, 3> denWR{ denWR1, denWR2, denWR3 };
    Offense denOff(denQB, denWR, denTE, denRB);

    //make defense structure (takes DE vector size = 6)
    array<DE, 6> denDE{ denDE1, denDE2, denDE3, denDE4, denDE5, denDE6 };
    Defense denDef(denDE);

    //make special teams structure
    STeams denST(denK, denP, denR);

    //CHIEFS TEAM CREATION****************************************************************************************************

    QB patrick("Patrick Mahomes", playerData);
    WR rashee("Rashee Rice", playerData);
    WR watson("Justin Watson", playerData);
    WR skyy("Skyy Moore", playerData);
    RB isiah("Isiah Pacheco", playerData);
    TE travis("Travis Kelce", playerData);
    DE karlaftis("George Karlaftis", playerData);
    DE nnadi("Derrick Nnadi", playerData);
    DE chris("Chris Jones", playerData);
    DE danna("Mike Danna", playerData);
    DE willie("Willie Gay", playerData);
    DE chenal("Leo Chenal", playerData);
    K harrison("Harrison Butker", playerData);
    P tommy("Tommy Townsend", playerData);
    R mecole("Mecole Hardman Jr.", playerData);

    array<WR, 3> kcWR{ rashee, watson, skyy };
    Offense kcOff(patrick, kcWR, travis, isiah);

    //make defense structure (takes DE vector size = 6)
    array<DE, 6> kcDE{ karlaftis, nnadi, chris, danna, willie, chenal };
    Defense kcDef(kcDE);

    //make special teams structure
    STeams kcST(harrison, tommy, mecole);

    //RAIDERS TEAM CREATION****************************************************************************************************

    QB lvQB("Jimmy Garoppolo", playerData);
    WR lvWR1("Davante Adams", playerData);
    WR lvWR2("Jakobi Meyers", playerData);
    WR lvWR3("Hunter Renfrow", playerData);
    RB lvRB("Josh Jacobs", playerData);
    TE lvTE("Michael Mayer", playerData);
    DE lvDE1("Maxx Crosby", playerData);
    DE lvDE2("Jerry Tillery", playerData);
    DE lvDE3("Bilal Nichols", playerData);
    DE lvDE4("Malcolm Koonce", playerData);
    DE lvDE5("Divine Deablo", playerData);
    DE lvDE6("Robert Spillane", playerData);
    K lvK("Daniel Carlson", playerData);
    P lvP("AJ Cole", playerData);
    R lvR("DeAndre Carter", playerData);

    //make offense structure (takes QB, WR vector size = 3, TE, RB)
    array<WR, 3> lvWR{ lvWR1, lvWR2, lvWR3 };
    Offense lvOff(lvQB, lvWR, lvTE, lvRB);

    //make defense structure (takes DE vector size = 6)
    array<DE, 6> lvDE{ lvDE1, lvDE2, lvDE3, lvDE4, lvDE5, lvDE6 };
    Defense lvDef(lvDE);

    //make special teams structure
    STeams lvST(lvK, lvP, lvR);

    //CHARGERS TEAM CREATION****************************************************************************************************

    QB lacQB("Justin Herbert", playerData);
    WR lacWR1("Keenan Allen", playerData);
    WR lacWR2("Quentin Johnston", playerData);
    WR lacWR3("Jalen Guyton", playerData);
    RB lacRB("Austin Ekeler", playerData);
    TE lacTE("Gerald Everett", playerData);
    DE lacDE1("Nick Williams", playerData);
    DE lacDE2("Sebastian Joseph-Day", playerData);
    DE lacDE3("Austin Johnson", playerData);
    DE lacDE4("Tuli Tuipulotu", playerData);
    DE lacDE5("Eric Kendricks", playerData);
    DE lacDE6("Kenneth Murray Jr.", playerData);
    K lacK("Cameron Dicker", playerData);
    P lacP("JK Scott", playerData);
    R lacR("Derius Davis", playerData);

    //make offense structure (takes QB, WR vector size = 3, TE, RB)
    array<WR, 3> lacWR{ lacWR1, lacWR2, lacWR3 };
    Offense lacOff(lacQB, lacWR, lacTE, lacRB);

    //make defense structure (takes DE vector size = 6)
    array<DE, 6> lacDE{ lacDE1, lacDE2, lacDE3, lacDE4, lacDE5, lacDE6 };
    Defense lacDef(lacDE);

    //make special teams structure
    STeams lacST(lacK, lacP, lacR);

    //COWBOYS TEAM CREATION****************************************************************************************************

    QB dalQB("Dak Prescott", playerData);
    WR dalWR1("CeeDee Lamb", playerData);
    WR dalWR2("Brandin Cooks", playerData);
    WR dalWR3("Michael Gallup", playerData);
    RB dalRB("Tony Pollard", playerData);
    TE dalTE("Jake Ferguson", playerData);
    DE dalDE1("DeMarcus Lawrence", playerData);
    DE dalDE2("Johnathan Hankins", playerData);
    DE dalDE3("Osa Odighizuwa", playerData);
    DE dalDE4("Dorance Armstrong", playerData);
    DE dalDE5("Damone Clark", playerData);
    DE dalDE6("Markquese Bell", playerData);
    K dalK("Brandon Aubrey", playerData);
    P dalP("Bryan Anger", playerData);
    R dalR("KaVontae Turpin", playerData);

    //make offense structure (takes QB, WR vector size = 3, TE, RB)
    array<WR, 3> dalWR{ dalWR1, dalWR2, dalWR3 };
    Offense dalOff(dalQB, dalWR, dalTE, dalRB);

    //make defense structure (takes DE vector size = 6)
    array<DE, 6> dalDE{ dalDE1, dalDE2, dalDE3, dalDE4, dalDE5, dalDE6 };
    Defense dalDef(dalDE);

    //make special teams structure
    STeams dalST(dalK, dalP, dalR);

    //GIANTS TEAM CREATION****************************************************************************************************

    QB nygQB("Daniel Jones", playerData);
    WR nygWR1("Darius Slayton", playerData);
    WR nygWR2("Wan'Dale Robinson", playerData);
    WR nygWR3("Jalin Hyatt", playerData);
    RB nygRB("Saquon Barkley", playerData);
    TE nygTE("Darren Waller", playerData);
    DE nygDE1("A'Shawn Robinson", playerData);
    DE nygDE2("Dexter Lawrence II", playerData);
    DE nygDE3("Jihad Ward", playerData);
    DE nygDE4("Azeez Ojulari", playerData);
    DE nygDE5("Bobby Okereke", playerData);
    DE nygDE6("Cam Brown", playerData);
    K nygK("Graham Gano", playerData);
    P nygP("Jamie Gillan", playerData);
    R nygR("Gunner Olszewski", playerData);

    //make offense structure (takes QB, WR vector size = 3, TE, RB)
    array<WR, 3> nygWR{ nygWR1, nygWR2, nygWR3 };
    Offense nygOff(nygQB, nygWR, nygTE, nygRB);

    //make defense structure (takes DE vector size = 6)
    array<DE, 6> nygDE{ nygDE1, nygDE2, nygDE3, nygDE4, nygDE5, nygDE6 };
    Defense nygDef(nygDE);

    //make special teams structure
    STeams nygST(nygK, nygP, nygR);

    //EAGLES TEAM CREATION****************************************************************************************************

    QB phiQB("Jalen Hurts", playerData);
    WR phiWR1("A.J. Brown", playerData);
    WR phiWR2("DeVonta Smith", playerData);
    WR phiWR3("Julio Jones", playerData);
    RB phiRB("D'Andre Swift", playerData);
    TE phiTE("Dallas Goedert", playerData);
    DE phiDE1("Brandon Graham", playerData);
    DE phiDE2("Jordan Davis", playerData);
    DE phiDE3("Fletcher Cox", playerData);
    DE phiDE4("Josh Sweat", playerData);
    DE phiDE5("Zach Cunningham", playerData);
    DE phiDE6("Nicholas Morrow", playerData);
    K phiK("Jake Elliott", playerData);
    P phiP("Braden Mann", playerData);
    R phiR("Britain Covey", playerData);

    //make offense structure (takes QB, WR vector size = 3, TE, RB)
    array<WR, 3> phiWR{ phiWR1, phiWR2, phiWR3 };
    Offense phiOff(phiQB, phiWR, phiTE, phiRB);

    //make defense structure (takes DE vector size = 6)
    array<DE, 6> phiDE{ phiDE1, phiDE2, phiDE3, phiDE4, phiDE5, phiDE6 };
    Defense phiDef(phiDE);

    //make special teams structure
    STeams phiST(phiK, phiP, phiR);

    //COMMANDERS TEAM CREATION****************************************************************************************************

    QB wasQB("Sam Howell", playerData);
    WR wasWR1("Terry McLaurin", playerData);
    WR wasWR2("Jahan Dotson", playerData);
    WR wasWR3("Curtis Samuel", playerData);
    RB wasRB("Brian Robinson Jr.", playerData);
    TE wasTE("Logan Thomas", playerData);
    DE wasDE1("James Smith-Williams", playerData);
    DE wasDE2("Daron Payne", playerData);
    DE wasDE3("Jonathan Allen", playerData);
    DE wasDE4("Casey Toohill", playerData);
    DE wasDE5("Khaleke Hudson", playerData);
    DE wasDE6("Cody Barton", playerData);
    K wasK("Joey Slye", playerData);
    P wasP("Tress Way", playerData);
    R wasR("Jamison Crowder", playerData);

    //make offense structure (takes QB, WR vector size = 3, TE, RB)
    array<WR, 3> wasWR{ wasWR1, wasWR2, wasWR3 };
    Offense wasOff(wasQB, wasWR, wasTE, wasRB);

    //make defense structure (takes DE vector size = 6)
    array<DE, 6> wasDE{ wasDE1, wasDE2, wasDE3, wasDE4, wasDE5, wasDE6 };
    Defense wasDef(wasDE);

    //make special teams structure
    STeams wasST(wasK, wasP, wasR);

    //BEARS TEAM CREATION****************************************************************************************************

    QB chiQB("Justin Fields", playerData);
    WR chiWR1("DJ Moore", playerData);
    WR chiWR2("Darnell Mooney", playerData);
    WR chiWR3("Equanimeous St. Brown", playerData);
    RB chiRB("Khalil Herbert", playerData);
    TE chiTE("Cole Kmet", playerData);
    DE chiDE1("Yannick Ngakoue", playerData);
    DE chiDE2("Andrew Billings", playerData);
    DE chiDE3("Justin Jones", playerData);
    DE chiDE4("Montez Sweat", playerData);
    DE chiDE5("T.J. Edwards", playerData);
    DE chiDE6("Tremaine Edmunds", playerData);
    K chiK("Cairo Santos", playerData);
    P chiP("Trenton Gill", playerData);
    R chiR("Trent Taylor", playerData);

    //make offense structure (takes QB, WR vector size = 3, TE, RB)
    array<WR, 3> chiWR{ chiWR1, chiWR2, chiWR3 };
    Offense chiOff(chiQB, chiWR, chiTE, chiRB);

    //make defense structure (takes DE vector size = 6)
    array<DE, 6> chiDE{ chiDE1, chiDE2, chiDE3, chiDE4, chiDE5, chiDE6 };
    Defense chiDef(chiDE);

    //make special teams structure
    STeams chiST(chiK, chiP, chiR);

    //LIONS TEAM CREATION****************************************************************************************************

    QB detQB("Jared Goff", playerData);
    WR detWR1("Amon-Ra St. Brown", playerData);
    WR detWR2("Josh Reynolds", playerData);
    WR detWR3("Jameson Williams", playerData);
    RB detRB("David Montgomery", playerData);
    TE detTE("Sam LaPorta", playerData);
    DE detDE1("Aidan Hutchinson", playerData);
    DE detDE2("Alim McNeill", playerData);
    DE detDE3("Benito Jones", playerData);
    DE detDE4("John Cominsky", playerData);
    DE detDE5("Jack Campbell", playerData);
    DE detDE6("Alex Anzalone", playerData);
    K detK("Riley Patterson", playerData);
    P detP("Jack Fox", playerData);
    R detR("Kalif Raymond", playerData);

    //make offense structure (takes QB, WR vector size = 3, TE, RB)
    array<WR, 3> detWR{ detWR1, detWR2, detWR3 };
    Offense detOff(detQB, detWR, detTE, detRB);

    //make defense structure (takes DE vector size = 6)
    array<DE, 6> detDE{ detDE1, detDE2, detDE3, detDE4, detDE5, detDE6 };
    Defense detDef(detDE);

    //make special teams structure
    STeams detST(detK, detP, detR);

    //PACKERS TEAM CREATION****************************************************************************************************

    QB gbQB("Jordan Love", playerData);
    WR gbWR1("Christian Watson", playerData);
    WR gbWR2("Romeo Doubs", playerData);
    WR gbWR3("Jayden Reed", playerData);
    RB gbRB("Aaron Jones", playerData);
    TE gbTE("Tucker Kraft", playerData);
    DE gbDE1("Kenny Clark", playerData);
    DE gbDE2("T.J. Slaton", playerData);
    DE gbDE3("Devonte Wyatt", playerData);
    DE gbDE4("Preston Smith", playerData);
    DE gbDE5("De'Vondre Campbell", playerData);
    DE gbDE6("Quay Walker", playerData);
    K gbK("Anders Carlson", playerData);
    P gbP("Daniel Whelan", playerData);
    R gbR("Keisean Nixon", playerData);

    //make offense structure (takes QB, WR vector size = 3, TE, RB)
    array<WR, 3> gbWR{ gbWR1, gbWR2, gbWR3 };
    Offense gbOff(gbQB, gbWR, gbTE, gbRB);

    //make defense structure (takes DE vector size = 6)
    array<DE, 6> gbDE{ gbDE1, gbDE2, gbDE3, gbDE4, gbDE5, gbDE6 };
    Defense gbDef(gbDE);

    //make special teams structure
    STeams gbST(gbK, gbP, gbR);

    //VIKINGS TEAM CREATION****************************************************************************************************

    QB minQB("Kirk Cousins", playerData);
    WR minWR1("Justin Jefferson", playerData);
    WR minWR2("Jordan Addison", playerData);
    WR minWR3("K.J. Osborn", playerData);
    RB minRB("Cam Akers", playerData);
    TE minTE("T.J. Hockenson", playerData);
    DE minDE1("Jaquelin Roy", playerData);
    DE minDE2("Harrison Phillips", playerData);
    DE minDE3("Jonathan Bullard", playerData);
    DE minDE4("Danielle Hunter", playerData);
    DE minDE5("Ivan Pace Jr.", playerData);
    DE minDE6("Troy Dye", playerData);
    K minK("Greg Joseph", playerData);
    P minP("Ryan Wright", playerData);
    R minR("Brandon Powell", playerData);

    //make offense structure (takes QB, WR vector size = 3, TE, RB)
    array<WR, 3> minWR{ minWR1, minWR2, minWR3 };
    Offense minOff(minQB, minWR, minTE, minRB);

    //make defense structure (takes DE vector size = 6)
    array<DE, 6> minDE{ minDE1, minDE2, minDE3, minDE4, minDE5, minDE6 };
    Defense minDef(minDE);

    //make special teams structure
    STeams minST(minK, minP, minR);

    //FALCONS TEAM CREATION****************************************************************************************************

    QB atlQB("Desmond Ridder", playerData);
    WR atlWR1("Drake London", playerData);
    WR atlWR2("Van Jefferson", playerData);
    WR atlWR3("Mack Hollins", playerData);
    RB atlRB("Bijan Robinson", playerData);
    TE atlTE("Kyle Pitts", playerData);
    DE atlDE1("Calais Campbell", playerData);
    DE atlDE2("David Onyemata", playerData);
    DE atlDE3("Kentavius Street", playerData);
    DE atlDE4("Arnold Ebiketie", playerData);
    DE atlDE5("Nate Landman", playerData);
    DE atlDE6("Kaden Elliss", playerData);
    K atlK("Younghoe Koo", playerData);
    P atlP("Bradley Pinion", playerData);
    R atlR("Dee Alford", playerData);

    //make offense structure (takes QB, WR vector size = 3, TE, RB)
    array<WR, 3> atlWR{ atlWR1, atlWR2, atlWR3 };
    Offense atlOff(atlQB, atlWR, atlTE, atlRB);

    //make defense structure (takes DE vector size = 6)
    array<DE, 6> atlDE{ atlDE1, atlDE2, atlDE3, atlDE4, atlDE5, atlDE6 };
    Defense atlDef(atlDE);

    //make special teams structure
    STeams atlST(atlK, atlP, atlR);

    //PANTHERS TEAM CREATION****************************************************************************************************

    QB carQB("Bryce Young", playerData);
    WR carWR1("Adam Thielen", playerData);
    WR carWR2("Jonathan Mingo", playerData);
    WR carWR3("DJ Chark Jr.", playerData);
    RB carRB("Chuba Hubbard", playerData);
    TE carTE("Hayden Hurst", playerData);
    DE carDE1("DeShawn Williams", playerData);
    DE carDE2("Shy Tuttle", playerData);
    DE carDE3("Derrick Brown", playerData);
    DE carDE4("Brian Burns", playerData);
    DE carDE5("Deion Jones", playerData);
    DE carDE6("Frankie Luvu", playerData);
    K carK("Eddy Pineiro", playerData);
    P carP("Johnny Hekker", playerData);
    R carR("Raheem Blackshear", playerData);

    //make offense structure (takes QB, WR vector size = 3, TE, RB)
    array<WR, 3> carWR{ carWR1, carWR2, carWR3 };
    Offense carOff(carQB, carWR, carTE, carRB);

    //make defense structure (takes DE vector size = 6)
    array<DE, 6> carDE{ carDE1, carDE2, carDE3, carDE4, carDE5, carDE6 };
    Defense carDef(carDE);

    //make special teams structure
    STeams carST(carK, carP, carR);

    //SAINTS TEAM CREATION****************************************************************************************************

    QB noQB("Derek Carr", playerData);
    WR noWR1("Chris Olave", playerData);
    WR noWR2("Rashid Shaheed", playerData);
    WR noWR3("Michael Thomas", playerData);
    RB noRB("Alvin Kamara", playerData);
    TE noTE("Juwan Johnson", playerData);
    DE noDE1("Cameron Jordan", playerData);
    DE noDE2("Nathan Shepherd", playerData);
    DE noDE3("Khalen Saunders", playerData);
    DE noDE4("Carl Granderson", playerData);
    DE noDE5("Pete Werner", playerData);
    DE noDE6("Demario Davis", playerData);
    K noK("Blake Grupe", playerData);
    P noP("Lou Hedley", playerData);
    R noR("Lynn Bowden Jr.", playerData);

    //make offense structure (takes QB, WR vector size = 3, TE, RB)
    array<WR, 3> noWR{ noWR1, noWR2, noWR3 };
    Offense noOff(noQB, noWR, noTE, noRB);

    //make defense structure (takes DE vector size = 6)
    array<DE, 6> noDE{ noDE1, noDE2, noDE3, noDE4, noDE5, noDE6 };
    Defense noDef(noDE);

    //make special teams structure
    STeams noST(noK, noP, noR);

    //BUCCANEERS TEAM CREATION****************************************************************************************************

    QB tbQB("Baker Mayfield", playerData);
    WR tbWR1("Mike Evans", playerData);
    WR tbWR2("Chris Godwin", playerData);
    WR tbWR3("Trey Palmer", playerData);
    RB tbRB("Rachaad White", playerData);
    TE tbTE("Cade Otton", playerData);
    DE tbDE1("Calijah Kancey", playerData);
    DE tbDE2("Vita Vea", playerData);
    DE tbDE3("Logan Hall", playerData);
    DE tbDE4("Yaya Diaby", playerData);
    DE tbDE5("Devin White", playerData);
    DE tbDE6("Lavonte David", playerData);
    K tbK("Chase McLaughlin", playerData);
    P tbP("Jake Camarda", playerData);
    R tbR("Deven Thompkins", playerData);

    //make offense structure (takes QB, WR vector size = 3, TE, RB)
    array<WR, 3> tbWR{ tbWR1, tbWR2, tbWR3 };
    Offense tbOff(tbQB, tbWR, tbTE, tbRB);

    //make defense structure (takes DE vector size = 6)
    array<DE, 6> tbDE{ tbDE1, tbDE2, tbDE3, tbDE4, tbDE5, tbDE6 };
    Defense tbDef(tbDE);

    //make special teams structure
    STeams tbST(tbK, tbP, tbR);

    //CARDINALS TEAM CREATION****************************************************************************************************

    QB ariQB("Kyler Murray", playerData);
    WR ariWR1("Marquise Brown", playerData);
    WR ariWR2("Michael Wilson", playerData);
    WR ariWR3("Rondale Moore", playerData);
    RB ariRB("James Conner", playerData);
    TE ariTE("Trey McBride", playerData);
    DE ariDE1("Zaven Collins", playerData);
    DE ariDE2("Jonathan Ledbetter", playerData);
    DE ariDE3("Roy Lopez", playerData);
    DE ariDE4("Kevin Strong", playerData);
    DE ariDE5("Josh Woods", playerData);
    DE ariDE6("Krys Barnes", playerData);
    K ariK("Matt Prater", playerData);
    P ariP("Blake Gillikin", playerData);
    R ariR("Greg Dortch", playerData);

    //make offense structure (takes QB, WR vector size = 3, TE, RB)
    array<WR, 3> ariWR{ ariWR1, ariWR2, ariWR3 };
    Offense ariOff(ariQB, ariWR, ariTE, ariRB);

    //make defense structure (takes DE vector size = 6)
    array<DE, 6> ariDE{ ariDE1, ariDE2, ariDE3, ariDE4, ariDE5, ariDE6 };
    Defense ariDef(ariDE);

    //make special teams structure
    STeams ariST(ariK, ariP, ariR);

    //RAMS TEAM CREATION****************************************************************************************************

    QB larQB("Matthew Stafford", playerData);
    WR larWR1("Cooper Kupp", playerData);
    WR larWR2("Puka Nacua", playerData);
    WR larWR3("Tutu Atwell", playerData);
    RB larRB("Kyren Williams", playerData);
    TE larTE("Tyler Higbee", playerData);
    DE larDE1("Jonah Williams", playerData);
    DE larDE2("Kobie Turner", playerData);
    DE larDE3("Aaron Donald", playerData);
    DE larDE4("Byron Young", playerData);
    DE larDE5("Ernest Jones", playerData);
    DE larDE6("Christian Rozeboom", playerData);
    K larK("Lucas Havrisik", playerData);
    P larP("Ethan Evans", playerData);
    R larR("Austin Trammell", playerData);

    //make offense structure (takes QB, WR vector size = 3, TE, RB)
    array<WR, 3> larWR{ larWR1, larWR2, larWR3 };
    Offense larOff(larQB, larWR, larTE, larRB);

    //make defense structure (takes DE vector size = 6)
    array<DE, 6> larDE{ larDE1, larDE2, larDE3, larDE4, larDE5, larDE6 };
    Defense larDef(larDE);

    //make special teams structure
    STeams larST(larK, larP, larR);

    //49ERS TEAM CREATION****************************************************************************************************

    QB sfcQB("Brock Purdy", playerData);
    WR sfcWR1("Deebo Samuel", playerData);
    WR sfcWR2("Brandon Aiyuk", playerData);
    WR sfcWR3("Jauan Jennings", playerData);
    RB sfcRB("Christian McCaffrey", playerData);
    TE sfcTE("George Kittle", playerData);
    DE sfcDE1("Chase Young", playerData);
    DE sfcDE2("Arik Armstead", playerData);
    DE sfcDE3("Javon Hargrave", playerData);
    DE sfcDE4("Nick Bosa", playerData);
    DE sfcDE5("Dre Greenlaw", playerData);
    DE sfcDE6("Fred Warner", playerData);
    K sfcK("Jake Moody", playerData);
    P sfcP("Mitch Wishnowsky", playerData);
    R sfcR("Ray-Ray McCloud III", playerData);

    //make offense structure (takes QB, WR vector size = 3, TE, RB)
    array<WR, 3> sfcWR{ sfcWR1, sfcWR2, sfcWR3 };
    Offense sfcOff(sfcQB, sfcWR, sfcTE, sfcRB);

    //make defense structure (takes DE vector size = 6)
    array<DE, 6> sfcDE{ sfcDE1, sfcDE2, sfcDE3, sfcDE4, sfcDE5, sfcDE6 };
    Defense sfcDef(sfcDE);

    //make special teams structure
    STeams sfcST(sfcK, sfcP, sfcR);

    //SEAHAWKS TEAM CREATION****************************************************************************************************

    QB seaQB("Geno Smith", playerData);
    WR seaWR1("DK Metcalf", playerData);
    WR seaWR2("Tyler Lockett", playerData);
    WR seaWR3("Jaxon Smith-Njigba", playerData);
    RB seaRB("Kenneth Walker III", playerData);
    TE seaTE("Noah Fant", playerData);
    DE seaDE1("Dre'Mont Jones", playerData);
    DE seaDE2("Jarran Reed", playerData);
    DE seaDE3("Leonard Williams", playerData);
    DE seaDE4("Boye Mafe", playerData);
    DE seaDE5("Jordyn Brooks", playerData);
    DE seaDE6("Bobby Wagner", playerData);
    K seaK("Jason Myers", playerData);
    P seaP("Michael Dickson", playerData);
    R seaR("DeeJay Dallas", playerData);

    //make offense structure (takes QB, WR vector size = 3, TE, RB)
    array<WR, 3> seaWR{ seaWR1, seaWR2, seaWR3 };
    Offense seaOff(seaQB, seaWR, seaTE, seaRB);

    //make defense structure (takes DE vector size = 6)
    array<DE, 6> seaDE{ seaDE1, seaDE2, seaDE3, seaDE4, seaDE5, seaDE6 };
    Defense seaDef(seaDE);

    //make special teams structure
    STeams seaST(seaK, seaP, seaR);

    //AFC EAST
    Team bills("Buffalo", "Bills", bufOff, bufDef, bufST);
    Team dolphins("Miami", "Dolphins", miaOff, miaDef, miaST);
    Team patriots("New England", "Patriots", neOff, neDef, neST);
    Team jets("New York", "Jets", nyjOff, nyjDef, nyjST);

    //AFC NORTH
    Team ravens("Baltimore", "Ravens", balOff, balDef, balST);
    Team bengals("Cincinnati", "Bengals", cinOff, cinDef, cinST);
    Team browns("Cleveland", "Browns", cleOff, cleDef, cleST);
    Team steelers("Pittsburgh", "Steelers", pitOff, pitDef, pitST);

    //AFC SOUTH
    Team texans("Houston", "Texans", houOff, houDef, houST);
    Team colts("Indiannapolis", "Colts", indOff, indDef, indST);
    Team jaguars("Jacksonville", "Jaguars", jaxOff, jaxDef, jaxST);
    Team titans("Tennessee", "Titans", tenOff, tenDef, tenST);

    //AFC WEST
    Team broncos("Denver", "Broncos", denOff, denDef, denST);
    Team chiefs("Kansas City", "Chiefs", kcOff, kcDef, kcST);
    Team raiders("Las Vegas", "Raiders", lvOff, lvDef, lvST);
    Team chargers("Los Angeles", "Chargers", lacOff, lacDef, lacST);

    //NFC EAST
    Team cowboys("Dallas", "Cowboys", dalOff, dalDef, dalST);
    Team giants("New York", "Giants", nygOff, nygDef, nygST);
    Team eagles("Philadelphia", "Eagles", phiOff, phiDef, phiST);
    Team commanders("Washington", "Commanders", wasOff, wasDef, wasST);

    //NFC NORTH
    Team bears("Chicago", "Bears", chiOff, chiDef, chiST);
    Team lions("Detroit", "Lions", detOff, detDef, detST);
    Team packers("Green Bay", "Packers", gbOff, gbDef, gbST);
    Team vikings("Minnesota", "Vikings", minOff, minDef, minST);

    //NFC SOUTH
    Team falcons("Atlanta", "Falcons", atlOff, atlDef, atlST);
    Team panthers("Carolina", "Panthers", carOff, carDef, carST);
    Team saints("New Orleans", "Saints", noOff, noDef, noST);
    Team buccaneers("Tampa Bay", "Buccaneers", tbOff, tbDef, tbST);

    //NFC WEST
    Team cardinals("Arizona", "Cardinals", ariOff, ariDef, ariST);
    Team rams("Los Angeles", "Rams", larOff, larDef, larST);
    Team fourtyniners("San Francisco", "49ers", sfcOff, sfcDef, sfcST);
    Team seahawks("Seattle", "Seahawks", seaOff, seaDef, seaST);

    cout << "[Complete!]" << endl;
    
    //DIVISION/CONFERENCE CREATION****************************************************************************************************
    cout << "[Creating divisions . . .]" << endl;
    
    LocationName division = LocationName::EAST;
    Division eastAFC(division, bills, dolphins, patriots, jets);
    division = LocationName::NORTH;
    Division northAFC(division, ravens, bengals, browns, steelers);
    division = LocationName::SOUTH;
    Division southAFC(division, texans, colts, jaguars, titans);
    division = LocationName::WEST;
    Division westAFC(division, broncos, chiefs, raiders, chargers);

    ConferenceName conference = ConferenceName::AFC;
    Conference AFC(conference, eastAFC, northAFC, southAFC, westAFC);

    division = LocationName::EAST;
    Division eastNFC(division, cowboys, giants, eagles, commanders);
    division = LocationName::NORTH;
    Division northNFC(division, bears, lions, packers, vikings);
    division = LocationName::SOUTH;
    Division southNFC(division, falcons, panthers, saints, buccaneers);
    division = LocationName::WEST;
    Division westNFC(division, cardinals, rams, fourtyniners, seahawks);

    conference = ConferenceName::NFC;
    Conference NFC(conference, eastNFC, northNFC, southNFC, westNFC);

    cout << "[Complete!]" << endl;

    cout << "\nTHE REGULAR SEASON HAS STARTED**************************************************" << endl;

    //WEEK 1
    cout << "\n[Week 1}--------------------------------------------------" << endl;
    playWeek16Games(lions, chiefs, panthers, falcons, texans, ravens, bengals, browns, jaguars, colts, buccaneers, vikings, titans, saints, 
        fourtyniners, steelers, cardinals, commanders, packers, bears, raiders, broncos, dolphins, chargers, eagles, patriots, rams, seahawks, 
        cowboys, giants, bills, jets);

    //WEEK 2
    cout << "\n[Week 2}--------------------------------------------------" << endl;
    playWeek16Games(vikings, eagles, packers, falcons, raiders, bills, ravens, bengals, seahawks, lions, colts, texans, chiefs, jaguars, 
        bears, buccaneers, chargers, titans, giants, cardinals, fourtyniners, rams, jets, cowboys, commanders, broncos, dolphins, patriots, 
        saints, panthers, browns, steelers);

    //WEEK 3
    cout << "\n[Week 3}--------------------------------------------------" << endl;
    playWeek16Games(giants, fourtyniners, colts, ravens, titans, browns, falcons, lions, saints, packers, texans, jaguars, broncos, dolphins, 
        chargers, vikings, patriots, jets, bills, commanders, panthers, seahawks, cowboys, cardinals, bears, chiefs, steelers, raiders, 
        eagles, buccaneers, rams, bengals);

    //WEEK 4
    cout << "\n[Week 4}--------------------------------------------------" << endl;
    playWeek16Games(lions, packers, falcons, jaguars, dolphins, bills, vikings, panthers, broncos, bears, ravens, browns, steelers, texans, 
        rams, colts, buccaneers, saints, commanders, eagles, bengals, titans, raiders, chargers, patriots, cowboys, cardinals, fourtyniners, 
        chiefs, jets, seahawks, giants);

    //WEEK 5
    cout << "\n[Week 5}--------------------------------------------------" << endl;
    playWeek14Games(bears, commanders, jaguars, bills, texans, falcons, panthers, lions, titans, colts, giants, dolphins, saints, patriots, 
        ravens, steelers, bengals, cardinals, eagles, rams, jets, broncos, chiefs, vikings, cowboys, fourtyniners, packers, raiders);

    //WEEK 6
    cout << "\n[Week 6}--------------------------------------------------" << endl;
    playWeek15Games(broncos, chiefs, ravens, titans, commanders, falcons, vikings, bears, seahawks, bengals, fourtyniners, browns, 
        saints, texans, colts, jaguars, panthers, dolphins, patriots, raiders, lions, buccaneers, cardinals, rams, eagles, jets, giants, bills, 
        cowboys, chargers);

    //WEEK 7
    cout << "\n[Week 7}--------------------------------------------------" << endl;
    playWeek13Games(jaguars, saints, lions, ravens, raiders, bears, browns, colts, bills, patriots, commanders, giants, falcons, buccaneers, 
        steelers, rams, cardinals, seahawks, packers, broncos, chargers, chiefs, dolphins, eagles, fourtyniners, vikings);

    //WEEK 8
    cout << "\n[Week 8}--------------------------------------------------" << endl;
    playWeek16Games(buccaneers, bills, texans, panthers, rams, cowboys, vikings, packers, saints, colts, patriots, dolphins, jets, giants, 
        jaguars, steelers, falcons, titans, eagles, commanders, browns, seahawks, ravens, cardinals, chiefs, broncos, bengals, fourtyniners, 
        bears, chargers, raiders, lions);

    //WEEK 9
    cout << "\n[Week 9}--------------------------------------------------" << endl;
    playWeek14Games(titans, steelers, dolphins, chiefs, vikings, falcons, seahawks, ravens, cardinals, browns, rams, packers, 
        buccaneers, texans, commanders, patriots, bears, saints, colts, panthers, giants, raiders, cowboys, eagles, bills, bengals, 
        chargers, jets);

    //WEEK 10
    cout << "\n[Week 10}--------------------------------------------------" << endl;
    playWeek14Games(panthers, bears, colts, patriots, browns, ravens, texans, bengals, fourtyniners, jaguars, saints, vikings, 
        packers, steelers, titans, buccaneers, falcons, cardinals, lions, chargers, giants, cowboys, commanders, seahawks, jets, raiders, 
        broncos, bills);

    //WEEK 11
    cout << "\n[Week 11}--------------------------------------------------" << endl;
    playWeek14Games(bengals, ravens, cowboys, panthers, steelers, browns, bears, lions, chargers, packers, cardinals, texans, titans, jaguars, 
        raiders, dolphins, giants, commanders, buccaneers, fourtyniners, jets, bills, seahawks, rams, vikings, broncos, eagles, chiefs);

    //WEEK 12
    cout << "\n[Week 12}--------------------------------------------------" << endl;
    playWeek16Games(packers, lions, commanders, cowboys, fourtyniners, seahawks, dolphins, jets, saints, falcons, steelers, bengals, 
        jaguars, texans, buccaneers, colts, patriots, giants, panthers, titans, rams, cardinals, browns, broncos, chiefs, raiders, 
        bills, eagles, ravens, chargers, bears, vikings);

    //WEEK 13
    cout << "\n[Week 13}--------------------------------------------------" << endl;
    playWeek13Games(seahawks, cowboys, chargers, patriots, lions, saints, falcons, jets, cardinals, steelers, colts, titans, 
        dolphins, commanders, broncos, texans, panthers, buccaneers, browns, rams, fourtyniners, eagles, chiefs, packers, bengals, jaguars);

    //WEEK 14
    cout << "\n[Week 14}--------------------------------------------------" << endl;
    playWeek15Games(patriots, steelers, buccaneers, falcons, rams, ravens, lions, bears, colts, bengals, jaguars, browns, panthers, saints, 
        texans, jets, vikings, raiders, seahawks, fourtyniners, bills, chiefs, broncos, chargers, eagles, cowboys, titans, dolphins, 
        packers, giants);

    //WEEK 15
    cout << "\n[Week 15}--------------------------------------------------" << endl;
    playWeek16Games(chargers, raiders, vikings, bengals, steelers, colts, broncos, lions, falcons, panthers, bears, browns, 
        buccaneers, packers, jets, dolphins, giants, saints, texans, titans, chiefs, patriots, fourtyniners, cardinals, commanders, rams, 
        cowboys, bills, ravens, jaguars, eagles, seahawks);

    //WEEK 16
    cout << "\n[Week 16}--------------------------------------------------" << endl;
    playWeek16Games(saints, rams, bengals, steelers, bills, chargers, commanders, jets, lions, vikings, browns, texans, packers, panthers, 
        seahawks, titans, colts, falcons, jaguars, buccaneers, cowboys, dolphins, cardinals, bears, patriots, broncos, raiders, chiefs,
        giants, eagles, ravens, fourtyniners);

    //WEEK 17
    cout << "\n[Week 17}--------------------------------------------------" << endl;
    playWeek16Games(jets, browns, lions, cowboys, titans, texans, falcons, bears, dolphins, ravens, saints, buccaneers, patriots, bills, 
        cardinals, eagles, panthers, jaguars, raiders, colts, rams, giants, fourtyniners, commanders, steelers, seahawks, bengals, chiefs,
        chargers, broncos, packers, vikings);

    //WEEK 18
    cout << "\n[Week 18}--------------------------------------------------" << endl;
    playWeek16Games(bears, packers, cowboys, commanders, broncos, raiders, jaguars, titans, texans, colts, bills, dolphins, eagles, giants,
        seahawks, cardinals, vikings, lions, falcons, saints, jets, patriots, steelers, ravens, rams, fourtyniners, chiefs, chargers, 
        buccaneers, panthers, browns, bengals);

    cout << "\nTHE REGULAR SEASON HAS ENDED**************************************************" << endl;

    cout << endl;
    cout << "Buf. Bills: " << bills.wins << "-" << bills.ties << "-" << bills.losses << endl;
    cout << "Mia. Dolphins: " << dolphins.wins << "-" << dolphins.ties << "-" << dolphins.losses << endl;
    cout << "N.E. Patriots: " << patriots.wins << "-" << patriots.ties << "-" << patriots.losses << endl;
    cout << "N.Y. Jets: " << jets.wins << "-" << jets.ties << "-" << jets.losses << endl;

    cout << "Bal. Ravens: " << ravens.wins << "-" << ravens.ties << "-" << ravens.losses << endl;
    cout << "Cin. Bengals: " << bengals.wins << "-" << bengals.ties << "-" << bengals.losses << endl;
    cout << "Cle. Browns: " << browns.wins << "-" << browns.ties << "-" << browns.losses << endl;
    cout << "Pit. Steelers: " << steelers.wins << "-" << steelers.ties << "-" << steelers.losses << endl;

    cout << "Hou. Texans: " << texans.wins << "-" << texans.ties << "-" << texans.losses << endl;
    cout << "Ind. Colts: " << colts.wins << "-" << colts.ties << "-" << colts.losses << endl;
    cout << "Jax. Jaguars: " << jaguars.wins << "-" << jaguars.ties << "-" << jaguars.losses << endl;
    cout << "Ten. Titans: " << titans.wins << "-" << titans.ties << "-" << titans.losses << endl;

    cout << "Den. Broncos: " << broncos.wins << "-" << broncos.ties << "-" << broncos.losses << endl;
    cout << "K.C. Chiefs: " << chiefs.wins << "-" << chiefs.ties << "-" << chiefs.losses << endl;
    cout << "L.V. Raiders: " << raiders.wins << "-" << raiders.ties << "-" << raiders.losses << endl;
    cout << "L.A. Chargers: " << chargers.wins << "-" << chargers.ties << "-" << chargers.losses << endl;

    cout << "Dal. Cowboys: " << cowboys.wins << "-" << cowboys.ties << "-" << cowboys.losses << endl;
    cout << "N.Y. Giants: " << giants.wins << "-" << giants.ties << "-" << giants.losses << endl;
    cout << "Phi. Eagles: " << eagles.wins << "-" << eagles.ties << "-" << eagles.losses << endl;
    cout << "Was. Commanders: " << commanders.wins << "-" << commanders.ties << "-" << commanders.losses << endl;

    cout << "Chi. Bears: " << bears.wins << "-" << bears.ties << "-" << bears.losses << endl;
    cout << "Det. Lions: " << lions.wins << "-" << lions.ties << "-" << lions.losses << endl;
    cout << "G.B. Packers: " << packers.wins << "-" << packers.ties << "-" << packers.losses << endl;
    cout << "Min. Vikings: " << vikings.wins << "-" << vikings.ties << "-" << vikings.losses << endl;

    cout << "Atl. Falcons: " << falcons.wins << "-" << falcons.ties << "-" << falcons.losses << endl;
    cout << "Car. Panthers: " << panthers.wins << "-" << panthers.ties << "-" << panthers.losses << endl;
    cout << "N.O. Saints: " << saints.wins << "-" << saints.ties << "-" << saints.losses << endl;
    cout << "T.B. Buccaneers: " << buccaneers.wins << "-" << buccaneers.ties << "-" << buccaneers.losses << endl;

    cout << "Ari. Cardinals: " << cardinals.wins << "-" << cardinals.ties << "-" << cardinals.losses << endl;
    cout << "L.A. Rams: " << rams.wins << "-" << rams.ties << "-" << rams.losses << endl;
    cout << "S.F. 49ers: " << fourtyniners.wins << "-" << fourtyniners.ties << "-" << fourtyniners.losses << endl;
    cout << "Sea. Seahawks: " << seahawks.wins << "-" << seahawks.ties << "-" << seahawks.losses << endl;

    array<Team, 32> teams{bills, dolphins, patriots, jets, ravens, bengals, browns, steelers, texans, colts, jaguars, titans, broncos, 
        chiefs, raiders, chargers, cowboys, giants, eagles, commanders, bears, lions, packers, vikings, falcons, panthers, saints, buccaneers, 
        cardinals, rams, fourtyniners, seahawks};

    printPlayerData(teams);

    cout << "\nTHE LEAGUE HAS ENTERED THE PLAYOFFS**************************************************" << endl;

    array<Team*, 4> nfcLeaders = NFC.getConfLeaders();
    array<Team*, 4> afcLeaders = AFC.getConfLeaders();

    //PLAYOFFS ROUND ONE****************************************************************************************************
    cout << "\n[Round One]:" << endl;
    Game nfcR1_G1(*nfcLeaders[0], *nfcLeaders[3], false);
    Game nfcR1_G2(*nfcLeaders[1], *nfcLeaders[2], false);
    Game afcR1_G1(*afcLeaders[0], *afcLeaders[3], false);
    Game afcR1_G2(*afcLeaders[1], *afcLeaders[2], false);

    Team nfcSemiTeam1 = nfcR1_G1.gameHandler();
    nfcSemiTeam1.printTeam();
    cout << " have won their first round matchup." << endl;

    Team nfcSemiTeam2 = nfcR1_G2.gameHandler();
    nfcSemiTeam2.printTeam();
    cout << " have won their first round matchup." << endl;

    Team afcSemiTeam1 = afcR1_G1.gameHandler();
    afcSemiTeam1.printTeam();
    cout << " have won their first round matchup." << endl;

    Team afcSemiTeam2 = afcR1_G2.gameHandler();
    afcSemiTeam2.printTeam();
    cout << " have won their first round matchup." << endl;

    //CONFERENCE CHAMPIONSHIPS****************************************************************************************************
    cout << "\n[Conference Championships]:" << endl;
    Game nfcSemi(nfcSemiTeam1, nfcSemiTeam2, false);
    Game afcSemi(afcSemiTeam1, afcSemiTeam2, false);

    Team nfcBowlRep = nfcSemi.gameHandler();
    nfcBowlRep.printTeam();
    cout << " have won the NFC championship!" << endl;

    Team afcBowlRep = afcSemi.gameHandler();
    afcBowlRep.printTeam();
    cout << " have won the AFC championship!" << endl;

    //SUPERBOWL****************************************************************************************************
    cout << "\n[SuperBowl]:" << endl;
    Game superBowl(nfcBowlRep, afcBowlRep, true);

    Team superBowlWinner = superBowl.gameHandler();
    superBowlWinner.printTeam();
    cout << " have won the SuperBowl!\n" << endl;
}

//Parses .csv file into a 2d array
vector<vector<string>> CSVParse(string csv) {
    istringstream dataStream(csv);
    string line, val;
    vector<vector<string>> array;

    cout << "[Parsing player data . . .]" << endl;

    while (getline(dataStream, line)) {
        vector<string> valArray;
        stringstream ss(line);

        while (getline(ss, val, ',')) {
            valArray.push_back(val);
        }

        array.push_back(valArray);
    }

    cout << "[Complete!]" << endl;

    return array;
}

//Uses iterators to print entire 2d array.
void print2DArray(vector<vector<string>> array) {
    for (auto& row : array) {
        for (auto& val : row)
            cout << val << "  ";
        cout << "\n";
    }
}

void printPlayerData(array<Team, 32> teams) {
    ofstream playerCSV;
    playerCSV.open("output/playerData.csv");
                  //1         2          3         4         5       6     7    8     9      10    11     12      13     14     15       16     17      18         19      20        21    22
    playerCSV << "LAST_NAME,FIRST_NAME,POS,PASS_ATT,PASS_COMP,PASS_YDS,PASS_TD,REC_YD,TGTS,RECS,REC_TD,RUSH_YD,RUSH,RUSH_TD,SACK_YD,SACKS,SAFETIES,PUNT_YD,PUNTS,TOUCH_BACKS,KICK_YD,KICK_OFFS,FG_ATT,FG_MADE,RET_YDS,RETS,\n";

    for (int i = 0; i < teams.size(); i++) {
        playerCSV << teams[i].off.qb.lastName << "," << teams[i].off.qb.firstName << ",QB," << teams[i].off.qb.passAtt << "," << teams[i].off.qb.passComp << "," << teams[i].off.qb.passYds << "," << teams[i].off.qb.passTD << ",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,\n";
        array<WR, 3> recievers = teams[i].off.wr;

        for (int j = 0; j < recievers.size(); j++) {
            playerCSV << recievers[j].lastName << "," << recievers[j].firstName << ",WR,0,0,0,0," << recievers[j].recYds << "," << recievers[j].tgt << "," << recievers[j].rec << "," << recievers[j].recTD << ",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,\n";
        }

        playerCSV << teams[i].off.rb.lastName << "," << teams[i].off.rb.firstName << ",RB,0,0,0,0,0,0,0,0," << teams[i].off.rb.rushYds << "," << teams[i].off.rb.rush << "," << teams[i].off.rb.rushTD << ",0,0,0,0,0,0,0,0,0,0,0,0,\n";
        playerCSV << teams[i].off.te.lastName << "," << teams[i].off.te.firstName << ",TE,0,0,0,0," << teams[i].off.te.recYds << "," << teams[i].off.te.tgt << "," << teams[i].off.te.rec << "," << teams[i].off.te.recTD << ",0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,\n";

        array<DE, 6> defense = teams[i].def.def;
        for (int j = 0; j < defense.size(); j++) {
            playerCSV << defense[j].lastName << "," << defense[j].firstName << ",DE,0,0,0,0,0,0,0,0,0,0,0," << defense[j].sackYds << "," << defense[j].sacks << "," << defense[j].safeties << ",0,0,0,0,0,0,0,0,0,\n";
        }

        playerCSV << teams[i].spec.p.lastName << "," << teams[i].spec.p.firstName << ",P,0,0,0,0,0,0,0,0,0,0,0,0,0,0," << teams[i].spec.p.puntYds << "," << teams[i].spec.p.punts << "," << teams[i].spec.p.touchBacks << ",0,0,0,0,0,0,\n";
        playerCSV << teams[i].spec.k.lastName << "," << teams[i].spec.k.firstName << ",K,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0," << teams[i].spec.k.touchBacks << "," << teams[i].spec.k.kickYds << "," << teams[i].spec.k.kickOffs << "," << teams[i].spec.k.fgAtt << "," << teams[i].spec.k.fgMade << ",0,0,\n";
        playerCSV << teams[i].spec.r.lastName << "," << teams[i].spec.r.firstName << ",R,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0," << teams[i].spec.r.retYds << "," << teams[i].spec.r.returns << ",\n";
    }

    playerCSV.close();
}

void playWeek16Games(Team& t1, Team& t2, Team& t3, Team& t4, Team& t5, Team& t6, Team& t7, Team& t8, 
    Team& t9, Team& t10, Team& t11, Team& t12, Team& t13, Team& t14, Team& t15, Team& t16, 
    Team& t17, Team& t18, Team& t19, Team& t20, Team& t21, Team& t22, Team& t23, Team& t24,
    Team& t25, Team& t26, Team& t27, Team& t28, Team& t29, Team& t30, Team& t31, Team& t32) {
    Game game1(t1, t2, false);
    game1.gameHandler();
    Game game2(t3, t4, false);
    game2.gameHandler();
    Game game3(t5, t6, false);
    game3.gameHandler();
    Game game4(t7, t8, false);
    game4.gameHandler();
    Game game5(t9, t10, false);
    game5.gameHandler();
    Game game6(t11, t12, false);
    game6.gameHandler();
    Game game7(t13, t14, false);
    game7.gameHandler();
    Game game8(t15, t16, false);
    game8.gameHandler();
    Game game9(t17, t18, false);
    game9.gameHandler();
    Game game10(t19, t20, false);
    game10.gameHandler();
    Game game11(t21, t22, false);
    game11.gameHandler();
    Game game12(t23, t24, false);
    game12.gameHandler();
    Game game13(t25, t26, false);
    game13.gameHandler();
    Game game14(t27, t28, false);
    game14.gameHandler();
    Game game15(t29, t30, false);
    game15.gameHandler();
    Game game16(t31, t32, false);
    game16.gameHandler();
}

void playWeek15Games(Team& t1, Team& t2, Team& t3, Team& t4, Team& t5, Team& t6, Team& t7, Team& t8,
    Team& t9, Team& t10, Team& t11, Team& t12, Team& t13, Team& t14, Team& t15, Team& t16,
    Team& t17, Team& t18, Team& t19, Team& t20, Team& t21, Team& t22, Team& t23, Team& t24,
    Team& t25, Team& t26, Team& t27, Team& t28, Team& t29, Team& t30) {
    Game game1(t1, t2, false);
    game1.gameHandler();
    Game game2(t3, t4, false);
    game2.gameHandler();
    Game game3(t5, t6, false);
    game3.gameHandler();
    Game game4(t7, t8, false);
    game4.gameHandler();
    Game game5(t9, t10, false);
    game5.gameHandler();
    Game game6(t11, t12, false);
    game6.gameHandler();
    Game game7(t13, t14, false);
    game7.gameHandler();
    Game game8(t15, t16, false);
    game8.gameHandler();
    Game game9(t17, t18, false);
    game9.gameHandler();
    Game game10(t19, t20, false);
    game10.gameHandler();
    Game game11(t21, t22, false);
    game11.gameHandler();
    Game game12(t23, t24, false);
    game12.gameHandler();
    Game game13(t25, t26, false);
    game13.gameHandler();
    Game game14(t27, t28, false);
    game14.gameHandler();
    Game game15(t29, t30, false);
    game15.gameHandler();
}

void playWeek14Games(Team& t1, Team& t2, Team& t3, Team& t4, Team& t5, Team& t6, Team& t7, Team& t8,
    Team& t9, Team& t10, Team& t11, Team& t12, Team& t13, Team& t14, Team& t15, Team& t16,
    Team& t17, Team& t18, Team& t19, Team& t20, Team& t21, Team& t22, Team& t23, Team& t24,
    Team& t25, Team& t26, Team& t27, Team& t28) {
    Game game1(t1, t2, false);
    game1.gameHandler();
    Game game2(t3, t4, false);
    game2.gameHandler();
    Game game3(t5, t6, false);
    game3.gameHandler();
    Game game4(t7, t8, false);
    game4.gameHandler();
    Game game5(t9, t10, false);
    game5.gameHandler();
    Game game6(t11, t12, false);
    game6.gameHandler();
    Game game7(t13, t14, false);
    game7.gameHandler();
    Game game8(t15, t16, false);
    game8.gameHandler();
    Game game9(t17, t18, false);
    game9.gameHandler();
    Game game10(t19, t20, false);
    game10.gameHandler();
    Game game11(t21, t22, false);
    game11.gameHandler();
    Game game12(t23, t24, false);
    game12.gameHandler();
    Game game13(t25, t26, false);
    game13.gameHandler();
    Game game14(t27, t28, false);
    game14.gameHandler();
}

void playWeek13Games(Team& t1, Team& t2, Team& t3, Team& t4, Team& t5, Team& t6, Team& t7, Team& t8,
    Team& t9, Team& t10, Team& t11, Team& t12, Team& t13, Team& t14, Team& t15, Team& t16,
    Team& t17, Team& t18, Team& t19, Team& t20, Team& t21, Team& t22, Team& t23, Team& t24,
    Team& t25, Team& t26) {
    Game game1(t1, t2, false);
    game1.gameHandler();
    Game game2(t3, t4, false);
    game2.gameHandler();
    Game game3(t5, t6, false);
    game3.gameHandler();
    Game game4(t7, t8, false);
    game4.gameHandler();
    Game game5(t9, t10, false);
    game5.gameHandler();
    Game game6(t11, t12, false);
    game6.gameHandler();
    Game game7(t13, t14, false);
    game7.gameHandler();
    Game game8(t15, t16, false);
    game8.gameHandler();
    Game game9(t17, t18, false);
    game9.gameHandler();
    Game game10(t19, t20, false);
    game10.gameHandler();
    Game game11(t21, t22, false);
    game11.gameHandler();
    Game game12(t23, t24, false);
    game12.gameHandler();
    Game game13(t25, t26, false);
    game13.gameHandler();
}