#pragma once
#include <string>
#include <vector>
#include <array>
#include <iostream>
#include <PlayerObjects.h>
#include <TeamObjects.h>
#include <GameObjects.h>

using namespace std;

enum class LocationName { NORTH, SOUTH, EAST, WEST, null };
enum class ConferenceName { AFC, NFC, null };

class Division {
public:
	LocationName divName = LocationName::null;

	Team& t1,& t2,& t3,& t4;

	Division( LocationName division, Team& team1, Team& team2, Team& team3, Team& team4 ): t1(team1), t2(team2), t3(team3), t4(team4) {
		divName = division;
	}

	Team* getDivChamp() {
		array<Team*, 4> divTeams = { &t1, &t2, &t3, &t4 };

		for (int i = 0; i < divTeams.size(); i++) {
			for (int j = i + 1; j < divTeams.size(); j++) {
				float teamiRecord = (float)(divTeams[i]->wins) / (float)(divTeams[i]->losses);
				float teamjRecord = (float)(divTeams[j]->wins) / (float)(divTeams[j]->losses);

				if (teamjRecord > teamiRecord) {
					Team* temp = divTeams[i];
					divTeams[i] = divTeams[j];
					divTeams[j] = temp;
				}
			}
		}

		return divTeams[0];
	}
};

class Conference {
public:
	ConferenceName conName = ConferenceName::null;

	Division d1, d2, d3, d4;

	Conference(ConferenceName conference, Division& division1, Division& division2, Division& division3, Division& division4) : d1(division1), d2(division2), d3(division3), d4(division4) {
		conName = conference;
	}

	array<Team*, 4> getConfLeaders() {
		array<Team*, 4> confLeaders = { d1.getDivChamp(), d2.getDivChamp(), d3.getDivChamp(), d4.getDivChamp() };

		for (int i = 0; i < confLeaders.size(); i++) {
			for (int j = i + 1; j < confLeaders.size(); j++) {
				float teamiRecord = (float)(confLeaders[i]->wins) / (float)(confLeaders[i]->losses);
				float teamjRecord = (float)(confLeaders[j]->wins) / (float)(confLeaders[j]->losses);

				if (teamjRecord > teamiRecord) {
					Team* temp = confLeaders[i];
					confLeaders[i] = confLeaders[j];
					confLeaders[j] = temp;
				}
			}
		}

		if (conName == ConferenceName::AFC) {
			cout << "\nAFC Seeding: " << endl;
		}
		else if (conName == ConferenceName::NFC) {
			cout << "\nNFC Seeding: " << endl;
		}

		for (int i = 0; i < confLeaders.size(); i++) {
			cout << i+1 << "-Seed: ";
			confLeaders[i]->printTeam();
			cout << " (" << confLeaders[i]->wins << "-" << confLeaders[i]->ties << "-" << confLeaders[i]->losses << ")" << endl;
		}

		return confLeaders;
	}
};