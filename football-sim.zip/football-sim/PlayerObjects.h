#pragma once
#include <string>
#include <string.h>
#include <iostream>
#include <sstream>
#include <random>

using namespace std;

int numRoll(int min, int max);
float pctRoll();

class Player {
public:
    string lastName = "";
    string firstName = "";
    int jerseyNum = 0;

    vector<string> splitString(string& s)
    {
        stringstream ss(s);
        vector<string> words;

        for (string w; ss >> w; ) {
            words.push_back(w);
        }

        return words;
    }

    Player() {}

    Player(string name) {
        vector<string> splitName = splitString(name);

        firstName = splitName[0];
        lastName = splitName[1];
    }

    void printName() {
        cout << firstName << " " << lastName;
    }

    void printPlayer() {
        cout << "Name: " << firstName << " " << lastName << endl;
        cout << "Jersey Number: " << jerseyNum << endl;
    }
};

class QB : public Player {
public:
    float passCompPct = 0.0; //index [13]
    float passIntPct = 0.0; //index [21]
    float passYdsPerAtt = 0.0; //index [16]

    //Collected Values
    int passAtt = 0, passComp = 0, passTD = 0;
    float  passYds = 0.0;

    /*
    Quarterback:
    ****************************************************************************************************
    *
    * - %50 chance for handoff or pass attempt
    *
    * - If passing:
    *     - Roll for completion; If roll fails, then roll for interception. If roll succeeds, then roll for yardage.
    *
    * - If running:
    *     - Let RB handle all rushing actions and calculations
    *
    ****************************************************************************************************
    */

    QB() {}

    explicit QB(string name, vector<vector<string>>& playerData) : Player(name) {
        int row = playerData.size();

        for (int i = 0; i < row; i++) {
            //Iterates over rows to find data for the player, given thir name
            if (playerData[i][2] == lastName && playerData[i][3] == firstName && playerData[i][5] == "QB") {
                try {
                    passCompPct = stof(playerData[i][13]);
                    passIntPct = stof(playerData[i][21]);
                    passYdsPerAtt = stof(playerData[i][16]);
                    jerseyNum = stoi(playerData[i][4]);
                }
                catch (exception e) {
                    cerr << "[ERROR] Error getting quarterback data for " << firstName << " " << lastName << "." << endl;
                }
                //Deletes the row used to populate this player's data in order to increase search performance later on.
                playerData.erase(playerData.begin() + i);
                
                break;
            }
        }
    }

    void printQB() {
        printPlayer();
        cout << "Completion %: " << passCompPct << endl;
        cout << "Interception %: " << passIntPct << endl;
        cout << "Average Yards/Pass: " << passYdsPerAtt << "\n" << endl;
    }

    bool runOrPassRoll() {
        float runOrPass = pctRoll();

        //cout << "Run-or-Pass Roll: " << runOrPass << "\nNeeded: <= 50.0" << endl;

        if (runOrPass <= 50.0) { //run
            return true;
        }
        else {
            return false;
        }
    }

    bool passCompRoll() {
        float qbCompPct = passCompPct;
        float qbCompRoll = pctRoll();

        //cout << "Pass Comp. Roll: " << qbCompRoll << "\nNeeded: <= " << qbCompPct << endl;

        if (qbCompRoll <= qbCompPct) {
            return true;
        }
        else {
            return false;
        }
    }

    bool passIntRoll() {
        float qbIntPct = passIntPct;
        float qbIntRoll = pctRoll();

        //cout << "Pass Int. Roll: " << qbIntRoll << "\nNeeded: <= " << qbIntPct << endl;

        if (qbIntRoll <= qbIntPct) {
            return true;
        }
        else {
            return false;
        }
    }
};

class WR : public Player {
public:
    int targets = 0; //index [42]
    int receptions = 0; //index [43]; receptions/targets = compPct
    float avgRecYds = 0.0; //index [45]
    
    //Calculated values:
    float compPct = 0.0;

    //Collected Values
    float recYds = 0.0;
    int tgt = 0, rec = 0, recTD = 0;

    /*
    Wide Reciever:
    ****************************************************************************************************
    *
    * - Calculate completion percentage
    *
    * - Roll for completion; If roll fails, then roll for interception. If roll succeeds, then roll for additional rushing yardage.
    *
    ****************************************************************************************************
    */

    WR() {}

    explicit WR(string name, vector<vector<string>>& playerData) : Player(name) {
        int row = playerData.size();

        for (int i = 0; i < row; i++) {
            //Iterates over rows to find data for the player, given thir name
            if (playerData[i][2] == lastName && playerData[i][3] == firstName && playerData[i][5] == "WR") {
                try {
                    targets = stoi(playerData[i][41]);
                    receptions = stoi(playerData[i][42]);
                    avgRecYds = stof(playerData[i][44]);
                    jerseyNum = stoi(playerData[i][4]);
                }
                catch (exception e) {
                    cerr << "[ERROR] Error getting quarterback data for " << firstName << " " << lastName << "." << endl;
                }

                //Deletes the row used to populate this player's data in order to increase search performance later on.
                playerData.erase(playerData.begin() + i);

                break;
            }
        }

        compPct = (static_cast<float>(receptions) / static_cast<float>(targets)) * 100;
    }

    void printWR() {
        printPlayer();
        cout << "Targets: " << targets << endl;
        cout << "Receptions: " << receptions << endl;
        cout << "Avg Yards/Reception: " << avgRecYds << endl;
        cout << "Completion %: " << compPct << "\n" << endl;
    }

    bool passCompRoll() {
        float wrCompPct = compPct;
        float wrCompRoll = pctRoll();

        //cout << "Catch Roll: " << wrCompRoll << "\nNeeded: <= " << wrCompPct << endl;

        if (wrCompRoll <= wrCompPct) {
            return true;
        }
        else {
            return false;
        }
    }
};

class RB : public Player {
public:
    int rushAttPerGame = 0; //index [30]
    int rushFumblesPerSea = 0; //index [41]; rushFumblesPerSea/17 = rushFumblesPerGame; rushFumblesPerGame/rushAttPerGame = rushFumblePct
    float avgRushYds = 0.0;  //index [32]
    
    //Calculated values:
    float rushFumblePct = 0.0;

    //Collected Values
    float rushYds = 0.0;
    int rush = 0, rushTD = 0;

    /*
    Running Back:
    ****************************************************************************************************
    *
    * - Calculate rushing fumble percentage
    *
    * - Roll for yardage
    *
    * - Roll for fumble; If roll fails, then yardage stands. If roll succeeds, then 50% chance of turnover.
    *
    ****************************************************************************************************
    */

    RB() {}

    explicit RB(string name, vector<vector<string>>& playerData) : Player(name) {
        int row = playerData.size();

        for (int i = 0; i < row; i++) {
            //Iterates over rows to find data for the player, given thir name
            if (playerData[i][2] == lastName && playerData[i][3] == firstName && playerData[i][5] == "RB") {
                try {
                    rushAttPerGame = stoi(playerData[i][30]);
                    rushFumblesPerSea = stoi(playerData[i][41]);
                    avgRushYds = stof(playerData[i][32]);
                    jerseyNum = stoi(playerData[i][4]);
                }
                catch (exception e) {
                    cerr << "[ERROR] Error getting runnung back data for " << firstName << " " << lastName << "." << endl;
                }

                //Deletes the row used to populate this player's data in order to increase search performance later on.
                playerData.erase(playerData.begin() + i);

                break;
            }
        }

        rushFumblePct = (static_cast<float>(rushFumblesPerSea) / 17) / static_cast<float>(rushAttPerGame) * 100;
    }

    void printRB() {
        printPlayer();
        cout << "Rush Attempts/Game: " << rushAttPerGame << endl;
        cout << "Rushing Fumbles/Season: " << rushFumblesPerSea << endl;
        cout << "Average Yards/Carry: " << avgRushYds << endl;
        cout << "Rushing Fumble %: " << rushFumblePct << "\n" << endl;
    }

    bool fumbleRoll() {
        float fumbleChance = rushFumblePct;
        float fumbleRoll = pctRoll();

        //cout << "Fumble Roll: " << fumbleRoll << "\nNeeded: <= " << fumbleChance << endl;

        if (fumbleRoll <= fumbleChance) {//fumble
            return true;
        }
        else {
            return false;
        }
    }
};

class TE : public Player {
public:
    int targetsPerSeason = 0;  //index [42]
    int receptionsPerSeason = 0; //index [43]; receptions/targets = compPct
    float avgRecYds = 0.0; //index [45]
    
    //Calculated values:
    float compPct = 0.0;

    //Collected Values
    float recYds = 0.0;
    int tgt = 0, rec = 0, recTD = 0;

    /*
    Tight End:
    ****************************************************************************************************
    *
    * - Calculate completion percentage
    *
    * - Roll for completion; If roll fails, then roll for interception. If roll succeeds, then roll for additional rushing yardage.
    *
    ****************************************************************************************************
    */

    TE() {}

    explicit TE(string name, vector<vector<string>>& playerData) : Player(name) {
        int row = playerData.size();

        for (int i = 0; i < row; i++) {
            //Iterates over rows to find data for the player, given thir name
            if (playerData[i][2] == lastName && playerData[i][3] == firstName && playerData[i][5] == "TE") {
                try {
                    targetsPerSeason = stoi(playerData[i][41]);
                    receptionsPerSeason = stoi(playerData[i][42]);
                    avgRecYds = stof(playerData[i][44]);
                    jerseyNum = stoi(playerData[i][4]);
                }
                catch (exception e) {
                    cerr << "[ERROR] Error getting runnung back data for " << firstName << " " << lastName << "." << endl;
                }

                //Deletes the row used to populate this player's data in order to increase search performance later on.
                playerData.erase(playerData.begin() + i);

                break;
            }
        }

        compPct = (static_cast<float>(receptionsPerSeason) / static_cast<float>(targetsPerSeason)) * 100;
    }

    void printTE() {
        printPlayer();
        cout << "Targets: " << targetsPerSeason << endl;
        cout << "Receptions: " << receptionsPerSeason << endl;
        cout << "Avg Yards/Reception: " << avgRecYds << endl;
        cout << "Completion %: " << compPct << "\n" << endl;
    }

    bool passCompRoll() {
        float teCompPct = compPct;
        float teCompRoll = pctRoll();

        //cout << "Catch Roll: " << wrCompRoll << "\nNeeded: <= " << wrCompPct << endl;

        if (teCompRoll <= teCompPct) {
            return true;
        }
        else {
            return false;
        }
    }
};

class DE : public Player {
public:
    int sacksPerSeason = 0; //index [55]
    float sackYdsPerSeason = 0.0; //index [56]; sackYds/sacks = avgSackYds
    int defSnapsPlayed = 0; //index [157]; defSnapsPlayed/sacks = sackPct
    
    //Calculated values:
    float avgSackYds = 0.0;
    float sackPct = 0.0;

    //Collected Values
    float sackYds = 0.0;
    int sacks = 0, safeties = 0;

    /*
    Defense:
    ****************************************************************************************************
    *
    * - Before each play, roll for sack on QB.
    *
    * - If roll succeeds, then roll for loss of yards. If roll fails, then resume QB action.
    *
    ****************************************************************************************************
    */

    DE() {}

    explicit DE(string name, vector<vector<string>>& playerData) : Player(name) {
        int row = playerData.size();

        for (int i = 0; i < row; i++) {
            //Iterates over rows to find data for the player, given thir name
            if (playerData[i][2] == lastName && playerData[i][3] == firstName) {
                if (playerData[i][5] == "DE" || playerData[i][5] == "DT" || playerData[i][5] == "LB" || 
                    playerData[i][5] == "CB" || playerData[i][5] == "SS" || playerData[i][5] == "FS")
                    try {
                        sacksPerSeason = stoi(playerData[i][55]);
                        sackYdsPerSeason = stof(playerData[i][56]);
                        defSnapsPlayed = stoi(playerData[i][157]);
                        jerseyNum = stoi(playerData[i][4]);
                    }
                    catch (exception e) {
                        cerr << "[ERROR] Error getting defensive data for " << firstName << " " << lastName << "." << endl;
                    }

                    //Deletes the row used to populate this player's data in order to increase search performance later on.
                    playerData.erase(playerData.begin() + i);

                    break;
            }
        }

        avgSackYds = sackYdsPerSeason / static_cast<float>(sacksPerSeason);
        sackPct = (static_cast<float>(sacksPerSeason) * 17.0 / static_cast<float>(defSnapsPlayed)) * 100;
    }

    bool sackRoll() {
        float sackChance = sackPct;
        float sackRoll = pctRoll();

        if (sackRoll <= sackChance) {//sack
            return true;
        }
        else {
            return false;
        }
    }

    void printDE() {
        printPlayer();
        cout << "Sacks/Game: " << sacksPerSeason << endl;
        cout << "Sack Yards/Game: " << sackYdsPerSeason << endl;
        cout << "Defensive Snaps Played: " << defSnapsPlayed << endl;
        cout << "Average Yards/Sack: " << avgSackYds << endl;
        cout << "Sack %: " << sackPct << "\n" << endl;
    }
};

class P : public Player {
public:
    float avgPuntYds = 0.0; //index [135]

    //Collected Values
    float puntYds = 0.0;
    int punts = 0, touchBacks = 0;

    /*
    Special Teams:
    ****************************************************************************************************
    *
    * - If returning a kick, roll for yardage using avgKickRetYds.
    *
    * - If returning a punt, roll for yardage using avgPuntRetYds.
    *
    ****************************************************************************************************
    */

    P() {}

    explicit P(string name, vector<vector<string>>& playerData) : Player(name) {
        int row = playerData.size();

        for (int i = 0; i < row; i++) {
            //Iterates over rows to find data for the player, given thir name
            if (playerData[i][2] == lastName && playerData[i][3] == firstName && playerData[i][5] == "P") {
                try {
                    avgPuntYds = stof(playerData[i][135]);
                    jerseyNum = stoi(playerData[i][4]);
                }
                catch (exception e) {
                    cerr << "[ERROR] Error getting defensive data for " << firstName << " " << lastName << "." << endl;
                }

                //Deletes the row used to populate this player's data in order to increase search performance later on.
                playerData.erase(playerData.begin() + i);

                break;
            }
        }
    }

    void printP() {
        printPlayer();
        cout << "Avg Punt Yards: " << avgPuntYds << "\n" << endl;
    }
};

class K : public Player {
public:
    float avgKickOffYds = 0.0; //index [121]
    float fgPct20_29 = 0.0; //index [103]
    float fgPct30_39 = 0.0; //index [106]
    float fgPct40_49 = 0.0; //index [109]
    float fgPct50Plus = 0.0; //index [112]

    //Collected Values
    float kickYds = 0.0;
    int kickOffs = 0, touchBacks = 0, fgAtt = 0, fgMade = 0;

    /*
    Kicker:
    ****************************************************************************************************
    *
    * - Determine distance of field goal or extra point attempt.
    *
    * - Roll for kick success based on the distance.
    *
    ****************************************************************************************************
    */

    K() {}

    explicit K(string name, vector<vector<string>>& playerData) : Player(name) {
        int row = playerData.size();

        for (int i = 0; i < row; i++) {
            //Iterates over rows to find data for the player, given thir name
            if (playerData[i][2] == lastName && playerData[i][3] == firstName && playerData[i][5] == "K") {
                try {
                    avgKickOffYds = stof(playerData[i][123]);
                    fgPct20_29 = stof(playerData[i][103]);
                    fgPct30_39 = stof(playerData[i][106]);
                    fgPct40_49 = stof(playerData[i][109]);
                    fgPct50Plus = stof(playerData[i][112]);
                    jerseyNum = stoi(playerData[i][4]);
                }
                catch (exception e) {
                    cerr << "[ERROR] Error getting kicker data for " << firstName << " " << lastName << "." << endl;
                }

                //Deletes the row used to populate this player's data in order to increase search performance later on.
                playerData.erase(playerData.begin() + i);

                break;
            }
        }
    }

    void printK() {
        printPlayer();
        cout << "Avg Kickoff Yards: " << avgKickOffYds << endl;
        cout << "Field Goal Percentage (20-29 Yards): " << fgPct20_29 << endl;
        cout << "Field Goal Percentage (30-39 Yards): " << fgPct30_39 << endl;
        cout << "Field Goal Percentage (40-49 Yards): " << fgPct40_49 << endl;
        cout << "Field Goal Percentage (50+ Yards): " << fgPct50Plus << "\n" << endl;
    }

    bool kickPointRoll(float distance) {
        float kickRoll = pctRoll();

        if ( distance <= 29.0 ) {
            //cout << "Kick Roll: " << kickRoll << "\nNeeded: <= " << fgPct20_29 << endl;

            if (kickRoll <= fgPct20_29) {
                return true;
            }
            else {
                return false;
            }
        }
        else if ( 29.0 < distance && distance <= 39.0 ) {
            //cout << "Kick Roll: " << kickRoll << "\nNeeded: <= " << fgPct30_39 << endl;

            if (kickRoll <= fgPct30_39) {
                return true;
            }
            else {
                return false;
            }
        }
        else if ( 39.0 < distance && distance <= 49.0 ) {
            //cout << "Kick Roll: " << kickRoll << "\nNeeded: <= " << fgPct40_49 << endl;

            if (kickRoll <= fgPct40_49) {
                return true;
            }
            else {
                return false;
            }
        }
        else {
            //cout << "Kick Roll: " << kickRoll << "\nNeeded: <= " << fgPct50Plus << endl;

            if (kickRoll <= fgPct50Plus) {
                return true;
            }
            else {
                return false;
            }
        }
    }
};

class R : public Player {
public:
    float avgKickRetYds = 10.0; //index [78]
    float avgPuntRetYds = 10.0; //index [87]

    //Collected Values
    float retYds = 0.0;
    int returns = 0;

    /*
    Special Teams:
    ****************************************************************************************************
    *
    * - If returning a kick, roll for yardage using avgKickRetYds.
    *
    * - If returning a punt, roll for yardage using avgPuntRetYds.
    *
    ****************************************************************************************************
    */

    R() {}

    explicit R(string name, vector<vector<string>>& playerData) : Player(name) {
        int row = playerData.size();

        for (int i = 0; i < row; i++) {
            //Iterates over rows to find data for the player, given thir name
            if (playerData[i][2] == lastName && playerData[i][3] == firstName) {
                if (playerData[i][5] == "WR" || playerData[i][5] == "RB") {
                    try {
                        avgKickRetYds = stof(playerData[i][126]);
                        avgPuntRetYds = stof(playerData[i][146]);
                        jerseyNum = stoi(playerData[i][4]);
                    }
                    catch (exception e) {
                        cerr << "[ERROR] Error getting returner data for " << firstName << " " << lastName << "." << endl;
                    }

                    //Deletes the row used to populate this player's data in order to increase search performance later on.
                    playerData.erase(playerData.begin() + i);

                    break;
                }
            }
        }
    }

    void printR() {
        printPlayer();
        cout << "Avg Kick Return Yards: " << avgKickRetYds << endl;
        cout << "Avg Punt Return Yards: " << avgPuntRetYds << "\n" << endl;
    }
};

float pctRoll() {
    float pctRollFloat;

    for (int i = 0; i < 5; i++) {
        pctRollFloat = float(rand() % 1000);
    }

    return pctRollFloat / 10.0;
}

int numRoll(int min, int max) {
    int numRollInt;

    for (int i = 0; i < 5; i++) {
        numRollInt = float(rand() % max);
    }

    return numRollInt + min;
}