#pragma once
#include <string>
#include <vector>
#include <array>
#include <iostream>
#include <PlayerObjects.h>

using namespace std;

const int numWR = 3;
const int numDE = 6;

class Offense {
public:
	QB& qb;
	array<WR, numWR>& wr;
	TE& te;
	RB& rb;

	Offense(QB& quarterback, array<WR, numWR>& recievers, TE& tightEnd, RB& runningBack) : qb(quarterback), wr(recievers), te(tightEnd), rb(runningBack) {}
};

class Defense {
public:
	array<DE, numDE>& def;

	Defense(array<DE, numDE>& defense) : def(defense) {}
};

class STeams {
public:
	K& k;
	P& p;
	R& r;

	STeams(K& kicker, P& punter, R& returner) : k(kicker), p(punter), r(returner) {}
};

class Team {
public:
	string city = "City";
	string name = "Team";

	int weeklyScore = 0;
	int wins = 0;
	int losses = 0;
	int ties = 0;

	Offense& off; //Offense is made up of 1xQB, 3xWR, 1xTE, 1xRB.
	Defense& def; //Defense is made up of 6xDE (2 safeties, 1 linebacker, 1 defensive tackle, 2 defensive ends).
	STeams& spec; //Special Teams is made up of 1xK, 1xP, 1xR.

	Team(string teamCity, string teamName, Offense& offense, Defense& defense, STeams& specialTeams) : off(offense), def(defense), spec(specialTeams) {
		city = teamCity;
		name = teamName;
	}

	void printTeam() {
		cout << city << " " << name;
	}

	void newGame() {
		weeklyScore = 0;
	}
};