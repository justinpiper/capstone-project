#pragma once
#include <string>
#include <vector>
#include <array>
#include <iostream>
#include <PlayerObjects.h>
#include <TeamObjects.h>

using namespace std;

const int secInHalf = 1800;
const int secInOT = 600;
const int secInRunoff = 30;

const float fieldLength = 100.0;
const float kickOffPosition = 30.0;
const float extraPointPosition = 15.0;
const float kickOffTouchback = 25.0;
const float puntTouchback = 20.0;
const float playVariance = 0.2;

enum class Down { NEW, FIRST, SECOND, THIRD, FOURTH };
enum class Half { FIRST, SECOND, OT, END };

class Game {
public:
	Team& home, & away;
	Team* offTeam, * defTeam;
	Team* winner = & home;

	Down numDown = Down::NEW;
	Half numHalf = Half::FIRST;

	float ydsToGain = 10.0;
	int timeInSec = secInHalf;

	float fieldLocation = fieldLength;

	bool output = false;

	Game(Team& team1, Team& team2, bool selOutput) : home(team1), away(team2) {
		output = selOutput;
		team1.newGame();
		team2.newGame();

		offTeam = &home;
		defTeam = &away;

		if (output) {
			cout << "\nNew game started!" << endl;
			cout << "It's the ";
			away.printTeam();
			cout << " @ The ";
			home.printTeam();
			cout << ".\nThe ";
			offTeam->printTeam();
			cout << " are the home team and will start with the ball." << endl;
		}

		timeInSec = secInHalf;

		kickOff();
	}

	void kickOff() {
		K& kicker = defTeam->spec.k;
		float kickOffYds = playLengthRoll(kicker.avgKickOffYds);

		fieldLocation = kickOffPosition + kickOffYds;
		kicker.kickOffs++;
		kicker.kickYds += kickOffYds;

		if (output) {
			cout << kickOffYds << " yard kickoff by ";
			kicker.printName();
			cout << "." << endl;
		}

		if (fieldLocation >= 100.0 || fieldLocation <= 0.0) {
			if (output) {
				cout << "It's a touchback. The ball will be advanced to the " << kickOffTouchback << " yard line." << endl;
			}

			fieldLocation = fieldLength - kickOffTouchback;
			kicker.touchBacks++;
		}
		else {
			kickReturn();

			if (output) {
				//cout << "Now " << fieldLocation << " yards from the endzone." << endl;
			}
		}
	}

	void punt() {
		P& punter = defTeam->spec.p;
		float puntYds = playLengthRoll(punter.avgPuntYds);

		fieldLocation = fieldLength - fieldLocation + puntYds;
		punter.punts++;
		punter.puntYds += puntYds;

		if (output) {
			cout << puntYds << " yard punt by ";
			punter.printName();
			cout << "." << endl;
		}

		if (fieldLocation >= 100.0 || fieldLocation <= 0.0) {
			if (output) {
				cout << "It's a touchback. The ball will be advanced to the " << puntTouchback << " yard line." << endl;
			}

			fieldLocation = fieldLength - puntTouchback;
			punter.touchBacks++;
		}
		else {
			puntReturn();

			if (output) {
				//cout << "Now " << fieldLocation << " yards from the endzone." << endl;
			}
		}
	};

	void kickReturn() {
		R& returner = offTeam->spec.r;
		float kickRetYds = playLengthRoll(returner.avgKickRetYds);

		fieldLocation = fieldLocation + kickRetYds;
		returner.returns++;
		returner.retYds += kickRetYds;

		if (output) {
			cout << kickRetYds << " yard return by ";
			returner.printName();
			cout << "." << endl;
		}
	}

	void puntReturn() {
		R& returner = offTeam->spec.r;
		float puntRetYds = playLengthRoll(returner.avgPuntRetYds);

		fieldLocation = fieldLocation + puntRetYds;
		returner.returns++;
		returner.retYds += puntRetYds;

		if (output) {
			cout << puntRetYds << " yard return by ";
			returner.printName();
			cout << "." << endl;
		}
	}

	void changePosession() {
		newSetDowns();

		if (output) {
			cout << "Previously on offense: ";
			offTeam->printTeam();
			cout << "\nPreviously on defense: ";
			defTeam->printTeam();
			cout << "\nNow switching sides . . ." << endl;
		}

		Team* temp = offTeam;
		offTeam = defTeam;
		defTeam = temp;

		if (output) {
			cout << "Currently on offense: ";
			offTeam->printTeam();
			cout << "\nCurrently on defense: ";
			defTeam->printTeam();
			cout << endl;
		}
	}

	void newSetDowns() {
		numDown = Down::NEW;
		ydsToGain = 10.0;
	}

	void touchdownHandler() {
		if (fieldLocation <= 0.0) {
			if (output) {
				offTeam->printTeam();
				cout << " scored a touchdown." << endl;
			}

			offTeam->weeklyScore += 6;

			if (offTeam->spec.k.kickPointRoll(extraPointPosition)) {
				if (output) {
					cout << "And the extra point is good." << endl;
				}

				offTeam->weeklyScore += 1;
			}
			else {
				if (output) {
					cout << "And the extra point is no good!" << endl;
				}
			}

			changePosession();
			kickOff();
		}
	}

	void safetyHandler() {
		if (fieldLocation >= 100.0) {
			if (output) {
				defTeam->printTeam();
				cout << " scored a safety." << endl;
			}

			defTeam->weeklyScore += 2;

			newSetDowns();
			kickOff();
		}
	}

	void runSinglePlay() {
		QB& quarterBack = offTeam->off.qb;

		int selDE = numRoll(1, 6) - 1;
		DE& defense = defTeam->def.def[selDE];

		if (quarterBack.runOrPassRoll()) { //RB Rush
			//Text Output
			if (output) {
				quarterBack.printName();
				cout << " hands off the ball." << endl;
			}

			RB& runningBack = offTeam->off.rb;

			//Data Collection
			runningBack.rush++;

			//Text Output
			if (output) {
				runningBack.printName();
				cout << " is running the ball." << endl;
			}

			if (defense.sackRoll()) { //Sack Rusher
				//Game Logic
				float sackYards = playLengthRoll(defense.avgSackYds);
				fieldLocation += sackYards;
				ydsToGain += sackYards;

				//Data Collection
				defense.sacks++;
				defense.sackYds += sackYards;
				if (fieldLocation >= 100.0) {
					defense.safeties++;
				}

				//Text Output
				if (output) {
					runningBack.printName();
					cout << " was sacked by ";
					defense.printName();
					cout << " for a loss of " << sackYards << " yards." << endl;
				}
			}
			else if (runningBack.fumbleRoll()) {//RB Fumble
				//Text Output
				if (output) {
					runningBack.printName();
					cout << " fumbled the ball!" << endl;
				}

				//Game Logic
				changePosession();
				fieldLocation = fieldLength - fieldLocation;
			}
			else {//Successful Rush
				//Game Logic
				float rushYards = playLengthRoll(runningBack.avgRushYds);
				fieldLocation -= rushYards;
				ydsToGain -= rushYards;
				
				//Data Collection
				runningBack.rushYds += rushYards;
				if (fieldLocation <= 0.0) {
					runningBack.rushTD++;
				}

				//Text Output
				if (output) {
					runningBack.printName();
					cout << " successfuly ran the ball for a gain of " << rushYards << " yards." << endl;
				}
			}
		}
		else { //QB Pass
			//Data Collection
			quarterBack.passAtt++;
			
			//Text Output
			if (output) {
				quarterBack.printName();
				cout << " drops back." << endl;
			}

			if (defense.sackRoll()) { //Sack Passer
				//Game Logic
				float sackYards = playLengthRoll(defense.avgSackYds);
				fieldLocation += sackYards;
				ydsToGain += sackYards;

				//Data Collection
				defense.sacks++;
				defense.sackYds += sackYards;
				if (fieldLocation >= 100.0) {
					defense.safeties++;
				}

				//Text Output
				if (output) {
					quarterBack.printName();
					cout << " was sacked by ";
					defense.printName();
					cout << " for a loss of " << sackYards << " yards." << endl;
				}
			}
			else if (quarterBack.passCompRoll()) { //Pass Comp
				//Data Collection
				quarterBack.passComp++;
				
				//Text Output
				if (output) {
					quarterBack.printName();
					cout << " with a good throw." << endl;
				}

				int selWR = numRoll(1, 4) - 1;

				switch (selWR) {
				case 0:
				case 1:
				case 2:
				{
					WR& reciever = offTeam->off.wr[selWR];

					//Data Collection
					reciever.tgt++;

					if (reciever.passCompRoll()) { //Catch Comp WR
						//Game Logic
						float wrRecYards = playLengthRoll(reciever.avgRecYds);
						fieldLocation -= wrRecYards;
						ydsToGain -= wrRecYards;

						//Data Collection
						reciever.rec++;
						reciever.recYds += wrRecYards;
						quarterBack.passYds += wrRecYards;
						if (fieldLocation <= 0.0) {
							reciever.recTD++;
							quarterBack.passTD++;
						}

						//Text Output
						if (output) {
							reciever.printName();
							cout << " caught the ball for a gain of " << wrRecYards << " yards." << endl;
						}
					}
					else {
						//Text Output
						if (output) {
							reciever.printName();
							cout << " couldn't reel it in." << endl;
						}
					}
				}

				break;
				case 3:
				{
					TE& tightEnd = offTeam->off.te;

					//Data Collection
					tightEnd.tgt++;

					if (tightEnd.passCompRoll()) { //Catch Comp TE
						//Game Logic
						float teRecYards = playLengthRoll(tightEnd.avgRecYds);
						fieldLocation -= teRecYards;
						ydsToGain -= teRecYards;

						//Data Collection
						tightEnd.rec++;
						tightEnd.recYds += teRecYards;
						quarterBack.passYds += teRecYards;
						if (fieldLocation <= 0.0) {
							tightEnd.recTD++;
							quarterBack.passTD++;
						}

						//Text Output
						if (output) {
							tightEnd.printName();
							cout << " caught the ball for a gain of " << teRecYards << " yards." << endl;
						}
					}
					else {
						//Text Output
						if (output) {
							tightEnd.printName();
							cout << " couldn't reel it in." << endl;
						}
					}
				}
				}
			}
			else { //Catch Incomplete
				//Text Output
				if (output) {
					quarterBack.printName();
					cout << " with a bad throw." << endl;
				}

				if (quarterBack.passIntRoll()) { //Interception
					//Text Output
					if (output) {
						cout << "It's picked off." << endl;
					}

					//Game Logic
					changePosession();
					fieldLocation = fieldLength - fieldLocation;
				}
			}
		}
	}

	void posessionHandler() {
		if (ydsToGain <= 0.0) {
			if (output) {
				cout << "There's a new set of downs." << endl;
			}

			newSetDowns();
		}
		else {
			switch (numDown) {
			case Down::NEW:
				if (output) {
					cout << "It's first (1st) and " << ydsToGain << "." << endl;
				}

				numDown = Down::FIRST;
				runSinglePlay();

				break;
			case Down::FIRST:
				if (output) {
					cout << "It's second (2nd) and " << ydsToGain << "." << endl;
				}

				numDown = Down::SECOND;
				runSinglePlay();

				break;
			case Down::SECOND:
				if (output) {
					cout << "It's third (3rd) and " << ydsToGain << "." << endl;
				}

				numDown = Down::THIRD;
				runSinglePlay();

				break;
			case Down::THIRD:
				if (output) {
					cout << "It's fourth (4th) down." << endl;
				}

				numDown = Down::FOURTH;

				if (fieldLocation <= 50.0) {
					offTeam->spec.k.fgAtt++;

					if (output) {
						cout << "And they'll settle for the field goal." << endl;
					}

					if (offTeam->spec.k.kickPointRoll(fieldLocation)) {
						if (output) {
							cout << "The field goal is good." << endl;
						}

						offTeam->spec.k.fgMade++;

						offTeam->weeklyScore += 3;
						changePosession();
						kickOff();
					}
					else {
						if (output) {
							cout << "The kick is no good!" << endl;
						}

						fieldLocation = fieldLength - fieldLocation;
						changePosession();
					}
				}
				else {
					if (output) {
						cout << "And they'll punt it away." << endl;
					}

					changePosession();
					punt();
				}
			}
		}
	}

	void halfHandler() {
		while (timeInSec > 0) {
			posessionHandler();

			timeInSec = timeInSec - (playTimeRoll() + secInRunoff);
			touchdownHandler();
			safetyHandler();

			if (output) {
				cout << "Now " << fieldLocation << " yards from the endzone." << endl;
			}
		}
	}

	Team gameHandler() {
		while (numHalf != Half::END) {
			switch (numHalf) {
			case Half::FIRST:
				if (output) {
					cout << "\nIt's the start of the first half!--------------------------------------------------\n" << endl;
				}

				halfHandler();
				
				if (output) {
					cout << "\nIt's the end of the first half!--------------------------------------------------\n" << endl;
				}

				numHalf = Half::SECOND;
				break;

			case Half::SECOND:
				timeInSec = secInHalf;

				changePosession();
				kickOff();

				if (output) {
					cout << "\nIt's the start of the second half!--------------------------------------------------\n" << endl;
				}
				
				halfHandler();
				
				if (output) {
					cout << "\nIt's the end of the second half!--------------------------------------------------\n" << endl;
				}

				if (home.weeklyScore == away.weeklyScore) {
					numHalf = Half::OT;
				}
				else {
					numHalf = Half::END;
				}
				break;

			case Half::OT:
				timeInSec = secInOT;

				changePosession();
				kickOff();

				if (output) {
					cout << "\nIt's the start of overtime!--------------------------------------------------\n" << endl;
				}

				halfHandler();
				
				if (output) {
					cout << "\nIt's the end of overtime!--------------------------------------------------\n" << endl;
				}

				numHalf = Half::END;
				break;
			}
		}

		winHandler();

		return *winner;
	}

	void winHandler() {
		if (home.weeklyScore > away.weeklyScore) {
			home.wins++;
			away.losses++;

			winner = &home;

			cout << endl;
			home.printTeam();
			cout << " have beat the ";
			away.printTeam();
			cout << ", " << home.weeklyScore << " - " << away.weeklyScore << endl;
		}
		else if (home.weeklyScore < away.weeklyScore) {
			away.wins++;
			home.losses++;

			winner = &away;

			cout << endl;
			away.printTeam();
			cout << " have beat the ";
			home.printTeam();
			cout << ", " << away.weeklyScore << " - " << home.weeklyScore << endl;
		}
		else {
			home.ties++;
			away.ties++;

			cout << endl;
			home.printTeam();
			cout << " and ";
			away.printTeam();
			cout << " played to a tie, " << home.weeklyScore << " - " << away.weeklyScore << endl;
		}
	}

	int playTimeRoll() {
		float playTime;

		for (int i = 0; i < 5; i++) {
			playTime = rand() % 8;
		}

		return playTime / 3;
	}

	float playLengthRoll(float length) {
		float playLength;
		float lengthLow = length * (1 - playVariance);
		float lengthHigh = length * (1 + playVariance);

		for (int i = 0; i < 5; i++) {
			playLength = ((float)rand()) / (float)RAND_MAX;
		}

		return (playLength * (lengthHigh - lengthLow)) + lengthLow;
	}
};